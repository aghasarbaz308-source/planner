export type DayKey = 'sat' | 'sun' | 'mon' | 'tue' | 'wed' | 'thu' | 'fri';

export type CategoryKey = 
  | 'university'
  | 'work'
  | 'python'
  | 'pytorch'
  | 'recovery'
  | 'gaming'
  | 'habit'
  | 'meeting'
  | 'custom';

export interface DayInfo {
  id: DayKey;
  nameFa: string;
  nameEn: string;
  shortFa: string;
  mood: string;          // روانشناسی روز: مثلاً شروع تازه، تمرکز عمیق، ریتم و تثبیت
  bgTint: string;        // پس‌زمینه خیلی ملایم و آرامش‌بخش
  borderTint: string;    // بوردر ملایم
  textTint: string;      // رنگ متنی خوانا و باوقار
  badgeBg: string;       // کپسول مود روز
  badgeText: string;
  dotColor: string;      // رنگ نشانگر نقطه
  printHeaderBg: string; // رنگ پس‌زمینه دقیق برای نسخه چاپی A4
  printBorder: string;   // رنگ حاشیه چاپی
}

export interface CategoryTheme {
  key: CategoryKey;
  label: string;
  tagline: string;
  // Light mode & print styling
  bgClass: string;
  borderClass: string;
  textClass: string;
  badgeClass: string;
  dotColor: string;
  printBg: string;
  printBorder: string;
  printText: string;
  icon: string;
}

export interface TimeBlock {
  id: string;
  title: string;
  category: CategoryKey;
  day: DayKey;
  startMinutes: number; // e.g. 07:00 = 420 minutes
  durationMinutes: number; // e.g. 30, 60, 90, 120
  subtitle?: string;
  note?: string;
  completed?: boolean;
}

export interface BlockTemplate {
  id: string;
  title: string;
  category: CategoryKey;
  defaultDuration: number;
  subtitle: string;
  description: string;
}

export interface WeeklyTaskItem {
  id: string;
  order: number;
  text: string;
  completed: boolean;
  priority: 'high' | 'medium' | 'normal';
  category?: CategoryKey;
  note?: string;
  createdAt: string;
}

export interface TimePhaseInfo {
  id: string;
  nameFa: string;
  nameEn: string;
  startHour: number;
  endHour: number;
  description: string;
  color: string;
  bgLight: string;
  borderLight: string;
  textDark: string;
  accentBar: string;
}

export interface PlannerRulesConfig {
  strictNonOverlap: boolean;         // منع قطعی همپوشانی و هل دادن خودکار تسک‌های بعدی (Cascade)
  bufferMinutesBetweenTasks: number; // فاصله محافظتی خودکار بین تسک‌ها (مثلاً 0 یا 5 یا 10 دقیقه)
  maxDailyDeepWorkHours: number;     // سقف مجاز کار عمیق روزانه (ساعت)
  warnDeepWorkOverLimit: boolean;    // نمایش هشدار در صورت عبور از سقف کار عمیق
  maxConsecutiveFocusMinutes: number;// سقف ریتم اولترادین تمرکز پیوسته قبل از استراحت (مثلاً 90 دقیقه)
  warnUltradianBreakNeeded: boolean; // پیشنهاد هوشمند استراحت بعد از 90 دقیقه تمرکز مداوم
  nightShieldStartHour: number;      // ساعت آغاز منطقه آرامش و منع کارهای پرفشار شبانه (مثلاً 22.5)
  warnNightShieldViolations: boolean;// هشدار چیدن کار عمیق در ساعات خواب
  minTaskDurationMinutes: number;    // حداقل طول هر کارت (دقیقه)
  maxTaskDurationMinutes: number;    // حداکثر طول هر کارت قبل از پیشنهاد شکستن (دقیقه)
}

export interface WeeklyPillarsGoals {
  deepWorkTargetHours: number;       // هدف هفتگی کار عمیق (AI & Python)
  workTargetHours: number;           // هدف هفتگی پروژه‌های کاری (Linux & Git)
  universityTargetHours: number;     // هدف هفتگی دانشگاه و درس
  recoveryTargetHours: number;       // هدف هفتگی ریکاوری و دوپامین سالم
  deepWorkTitle?: string;
  deepWorkSubtitle?: string;
  workTitle?: string;
  workSubtitle?: string;
  universityTitle?: string;
  universitySubtitle?: string;
  recoveryTitle?: string;
  recoverySubtitle?: string;
}

export interface PlannerData {
  version: string;
  title: string;
  weekRange: string;
  updatedAt: string;
  blocks: TimeBlock[];
  templates: BlockTemplate[];
  timePhases?: TimePhaseInfo[];
  weeklyNotes?: WeeklyTaskItem[];
  customCategoryColors?: Record<string, string>;
  plannerRules?: PlannerRulesConfig;
  weeklyGoals?: WeeklyPillarsGoals;
}
