import React, { useState } from 'react';
import {
  Brain,
  X,
  Sparkles,
  Award,
  ChevronDown,
  ChevronUp,
  Target,
  GraduationCap,
  Heart,
  Scale,
} from 'lucide-react';
import { TimeBlock, WeeklyPillarsGoals } from '../types';
import { toFaDigits, formatDurationFa } from '../constants/plannerConfig';
import { DEFAULT_WEEKLY_GOALS } from '../constants/defaultPlannerRules';

interface WeekStatsProps {
  blocks: TimeBlock[];
  onClose?: () => void;
  weeklyGoals?: WeeklyPillarsGoals;
  onOpenGoalsModal?: () => void;
}

export const WeekStats: React.FC<WeekStatsProps> = ({
  blocks,
  onClose,
  weeklyGoals = DEFAULT_WEEKLY_GOALS,
  onOpenGoalsModal,
}) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('weekstats_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleCollapse = () => {
    setIsCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('weekstats_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // 1. Deep Work: python + pytorch
  const deepWorkMinutes = blocks
    .filter((b) => b.category === 'python' || b.category === 'pytorch')
    .reduce((sum, b) => sum + b.durationMinutes, 0);

  // 2. Work & Career
  const workMinutes = blocks
    .filter((b) => b.category === 'work')
    .reduce((sum, b) => sum + b.durationMinutes, 0);

  // 3. University
  const universityMinutes = blocks
    .filter((b) => b.category === 'university')
    .reduce((sum, b) => sum + b.durationMinutes, 0);

  // 4. Recovery & Dopamine: recovery + gaming + habit
  const restMinutes = blocks
    .filter((b) => b.category === 'recovery' || b.category === 'gaming' || b.category === 'habit')
    .reduce((sum, b) => sum + b.durationMinutes, 0);

  const totalPlannedMinutes = blocks.reduce((sum, b) => sum + b.durationMinutes, 0);

  // Goals
  const deepGoalMins = (weeklyGoals.deepWorkTargetHours || 14) * 60;
  const workGoalMins = (weeklyGoals.workTargetHours || 14) * 60;
  const uniGoalMins = (weeklyGoals.universityTargetHours || 12) * 60;
  const restGoalMins = (weeklyGoals.recoveryTargetHours || 14) * 60;

  const deepPct = Math.min(100, Math.round((deepWorkMinutes / deepGoalMins) * 100));
  const workPct = Math.min(100, Math.round((workMinutes / workGoalMins) * 100));
  const uniPct = Math.min(100, Math.round((universityMinutes / uniGoalMins) * 100));
  const restPct = Math.min(100, Math.round((restMinutes / restGoalMins) * 100));

  const pillars = [
    {
      id: 'deep',
      title: weeklyGoals.deepWorkTitle || 'کار عمیق (AI & Python)',
      minutes: deepWorkMinutes,
      targetHours: weeklyGoals.deepWorkTargetHours || 14,
      pct: deepPct,
      icon: Sparkles,
      color: 'purple',
      badgeBg: 'bg-purple-100 text-purple-900 border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800',
      barColor: 'bg-purple-600',
      trackBg: 'bg-purple-100/70 dark:bg-purple-950/60',
      cardBg: 'bg-purple-50/40 dark:bg-purple-950/20 border-purple-200/60 dark:border-purple-900/50 hover:border-purple-300 dark:hover:border-purple-800',
    },
    {
      id: 'work',
      title: weeklyGoals.workTitle || 'پروژه کاری (Linux/Git)',
      minutes: workMinutes,
      targetHours: weeklyGoals.workTargetHours || 14,
      pct: workPct,
      icon: Award,
      color: 'sky',
      badgeBg: 'bg-sky-100 text-sky-900 border-sky-200 dark:bg-sky-950 dark:text-sky-300 dark:border-sky-800',
      barColor: 'bg-sky-600',
      trackBg: 'bg-sky-100/70 dark:bg-sky-950/60',
      cardBg: 'bg-sky-50/40 dark:bg-sky-950/20 border-sky-200/60 dark:border-sky-900/50 hover:border-sky-300 dark:hover:border-sky-800',
    },
    {
      id: 'uni',
      title: weeklyGoals.universityTitle || 'دانشگاه و تعهدات',
      minutes: universityMinutes,
      targetHours: weeklyGoals.universityTargetHours || 12,
      pct: uniPct,
      icon: GraduationCap,
      color: 'rose',
      badgeBg: 'bg-rose-100 text-rose-900 border-rose-200 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800',
      barColor: 'bg-rose-600',
      trackBg: 'bg-rose-100/70 dark:bg-rose-950/60',
      cardBg: 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200/60 dark:border-rose-900/50 hover:border-rose-300 dark:hover:border-rose-800',
    },
    {
      id: 'recovery',
      title: weeklyGoals.recoveryTitle || 'ریکاوری و تعادل',
      minutes: restMinutes,
      targetHours: weeklyGoals.recoveryTargetHours || 14,
      pct: restPct,
      icon: Heart,
      color: 'emerald',
      badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800',
      barColor: 'bg-emerald-600',
      trackBg: 'bg-emerald-100/70 dark:bg-emerald-950/60',
      cardBg: 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200/60 dark:border-emerald-900/50 hover:border-emerald-300 dark:hover:border-emerald-800',
    },
  ];

  return (
    <section
      aria-label="توازن هفتگی ارکان"
      className="bg-white dark:bg-slate-900 border-t-2 border-b-2 border-slate-300 dark:border-slate-700 px-4 sm:px-6 py-2.5 shadow-2xs no-print select-none transition-all duration-150"
      dir="rtl"
    >
      <div className="max-w-[1700px] mx-auto">
        {/* Sleek Architectural Header */}
        <div className="flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="w-6.5 h-6.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/70 border-2 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 flex items-center justify-center shrink-0 shadow-2xs">
              <Scale className="w-3.5 h-3.5 stroke-[2.2]" />
            </span>
            <div className="flex items-center gap-2">
              <span className="font-black text-slate-900 dark:text-slate-100 text-[13px] tracking-tight truncate">
                توازن ۴ رکن بنیادین هفته
              </span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 hidden md:inline">
                | ارزیابی بار شناختی و ریکاوری
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-300 dark:border-slate-700 shrink-0">
              کل برنامه: <strong className="text-slate-900 dark:text-white font-black">{formatDurationFa(totalPlannedMinutes)}</strong>
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onOpenGoalsModal && (
              <button
                type="button"
                onClick={onOpenGoalsModal}
                className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 active:scale-98 rounded-lg border border-indigo-300 dark:border-indigo-700 transition-colors cursor-pointer shadow-2xs"
                title="تنظیم ساعات هدف ۴ رکن"
              >
                <Target className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                <span>تنظیم اهداف</span>
              </button>
            )}

            <button
              type="button"
              onClick={toggleCollapse}
              className="p-1 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer border border-transparent hover:border-slate-300 dark:hover:border-slate-700"
              title={isCollapsed ? 'نمایش جزئیات ارکان' : 'جمع کردن پنل'}
            >
              {isCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                title="بستن این بخش"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* 4 Precision Pillar Cards with Crisp Architectural Grid Lines */}
        {!isCollapsed && (
          <div className="mt-2.5 pt-2.5 border-t border-slate-200 dark:border-slate-800">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {pillars.map((p) => {
                const Icon = p.icon;
                const isTargetReached = p.pct >= 100;
                return (
                  <div
                    key={p.id}
                    onClick={onOpenGoalsModal}
                    className={`px-3 py-2 rounded-xl border-2 transition-all cursor-pointer shadow-2xs hover:shadow-sm hover:border-indigo-400 dark:hover:border-indigo-500 ${p.cardBg} border-slate-300 dark:border-slate-700`}
                    title="کلیک برای شخصی‌سازی هدف این رکن"
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5 pb-1 border-b border-black/5 dark:border-white/5">
                      <div className="flex items-center gap-1.5 min-w-0 flex-1">
                        <Icon className="w-3.5 h-3.5 shrink-0 opacity-85" />
                        <span className="font-black text-slate-900 dark:text-slate-100 truncate text-[11.5px]">
                          {p.title}
                        </span>
                      </div>
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-md border shrink-0 ${p.badgeBg}`}>
                        {isTargetReached ? '✓ ' : ''}{toFaDigits(p.pct)}٪
                      </span>
                    </div>

                    <div className="flex items-baseline justify-between text-[11px] mb-1.5 font-mono">
                      <div className="flex items-baseline gap-1">
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-sans">ثبت شده:</span>
                        <span className="font-black text-slate-900 dark:text-slate-100">
                          {formatDurationFa(p.minutes)}
                        </span>
                      </div>
                      <div className="flex items-baseline gap-1 text-[10px] text-slate-500 dark:text-slate-400">
                        <span className="font-sans">هدف:</span>
                        <span className="font-bold">{toFaDigits(p.targetHours)} ساعت</span>
                      </div>
                    </div>

                    {/* Precision Progress Bar with Frame Border */}
                    <div className={`w-full h-2 rounded-full overflow-hidden border border-black/10 dark:border-white/15 ${p.trackBg}`}>
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${p.barColor}`}
                        style={{ width: `${p.pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
