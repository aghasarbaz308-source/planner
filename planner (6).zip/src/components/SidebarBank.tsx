import React, { useState, useMemo } from 'react';
import {
  Plus,
  GripVertical,
  Pencil,
  Copy,
  Trash2,
  Search,
  RotateCcw,
  Sparkles,
  Check,
  CalendarPlus,
  ClipboardCopy,
} from 'lucide-react';
import { BlockTemplate, CategoryKey } from '../types';
import { CATEGORIES, formatDurationFa, toFaDigits } from '../constants/plannerConfig';
import { CategoryIcon } from './CategoryIcon';
import { setDraggingTemplate, clearGlobalDragState } from '../utils/dragState';

interface SidebarBankProps {
  templates: BlockTemplate[];
  onOpenCreateTemplate: () => void;
  onEditTemplate: (template: BlockTemplate) => void;
  onDuplicateTemplate: (template: BlockTemplate) => void;
  onDeleteTemplate: (templateId: string) => void;
  onResetDefaultTemplates: () => void;
  onQuickAdd: (template: BlockTemplate) => void;
  onDragStartTemplate: (e: React.DragEvent, template: BlockTemplate) => void;
  onCopyTemplateToClipboard?: (template: BlockTemplate) => void;
}

export const SidebarBank: React.FC<SidebarBankProps> = ({
  templates,
  onOpenCreateTemplate,
  onEditTemplate,
  onDuplicateTemplate,
  onDeleteTemplate,
  onResetDefaultTemplates,
  onQuickAdd,
  onDragStartTemplate,
  onCopyTemplateToClipboard,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Filtered templates based on search & category
  const filteredTemplates = useMemo(() => {
    return templates.filter((tpl) => {
      const matchesSearch =
        !searchQuery.trim() ||
        tpl.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tpl.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (tpl.description && tpl.description.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory =
        selectedCategoryFilter === 'all' || tpl.category === selectedCategoryFilter;

      return matchesSearch && matchesCategory;
    });
  }, [templates, searchQuery, selectedCategoryFilter]);

  // Clean, ordered category filters
  const categoryGroups = [
    { key: 'all', label: 'همه' },
    { key: 'work', label: 'کار و پروژه' },
    { key: 'pytorch', label: 'پایتورچ' },
    { key: 'python', label: 'پایتون' },
    { key: 'university', label: 'دانشگاه' },
    { key: 'recovery', label: 'ریکاوری' },
    { key: 'habit', label: 'عادت‌ها' },
  ];

  const handleCopyAction = (tpl: BlockTemplate) => {
    if (onCopyTemplateToClipboard) {
      onCopyTemplateToClipboard(tpl);
    } else {
      onDuplicateTemplate(tpl);
    }
    setCopiedId(tpl.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleDragStart = (e: React.DragEvent, tpl: BlockTemplate) => {
    setDraggingTemplate(tpl);
    const serialized = JSON.stringify(tpl);
    e.dataTransfer.effectAllowed = 'copyMove';
    e.dataTransfer.setData('text/template-data', serialized);
    e.dataTransfer.setData('application/json', serialized);
    e.dataTransfer.setData('text/plain', serialized);
    if (onDragStartTemplate) {
      onDragStartTemplate(e, tpl);
    }
  };

  return (
    <aside
      aria-label="بانک الگوهای زمانی"
      className="w-full lg:w-80 xl:w-88 shrink-0 bg-white dark:bg-slate-900 border-b lg:border-b-0 lg:border-l-2 border-slate-300 dark:border-slate-700 p-3.5 sm:p-4 flex flex-col gap-3 no-print select-none shadow-xs transition-colors"
      dir="rtl"
    >
      {/* Header with Title & Add Template Button */}
      <div className="flex items-center justify-between pb-2.5 border-b-2 border-slate-300 dark:border-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-600 dark:bg-indigo-400 ring-4 ring-indigo-100 dark:ring-indigo-950" />
          <h2 className="text-xs font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-1.5">
            <span>بانک الگوها و تسک‌ها</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-mono font-bold border border-indigo-300 dark:border-indigo-700">
              {toFaDigits(templates.length)}
            </span>
          </h2>
        </div>

        <button
          onClick={onOpenCreateTemplate}
          id="add-custom-template-btn"
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-600 dark:hover:bg-indigo-500 active:scale-98 shadow-sm transition-all cursor-pointer border border-indigo-700 dark:border-indigo-500"
          title="ایجاد الگوی اختصاصی جدید"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>الگوی نو</span>
        </button>
      </div>

      {/* Guide Callout Pill for Zero Friction */}
      <div className="bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80 rounded-xl px-2.5 py-1.5 text-[10px] text-indigo-900 dark:text-indigo-200 flex items-center justify-between gap-1.5">
        <span className="leading-tight">
          💡 <strong>۲ روش استفاده:</strong> کارت را بکشید و در جدول رها کنید، یا <strong>«کپی»</strong> کنید و روی هر ساعت کلیک کنید.
        </span>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="جستجو در نام، مهارت یا موضوع..."
          className="w-full pr-8.5 pl-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:border-indigo-500 dark:focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:focus:ring-indigo-950/40 outline-hidden transition-all text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 font-medium"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1 cursor-pointer"
          >
            ✕
          </button>
        )}
      </div>

      {/* Ordered Category Filter Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800 scrollbar-none">
        {categoryGroups.map((grp) => {
          const isSelected = selectedCategoryFilter === grp.key;
          const count =
            grp.key === 'all'
              ? templates.length
              : templates.filter((t) => t.category === grp.key).length;
          if (count === 0 && grp.key !== 'all') return null;

          return (
            <button
              key={grp.key}
              onClick={() => setSelectedCategoryFilter(grp.key)}
              className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold whitespace-nowrap transition-all cursor-pointer shrink-0 flex items-center gap-1 border ${
                isSelected
                  ? 'bg-slate-900 text-white dark:bg-indigo-600 dark:text-white border-slate-900 dark:border-indigo-500 shadow-2xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-750'
              }`}
            >
              <span>{grp.label}</span>
              <span className="font-mono text-[9px] opacity-85">({toFaDigits(count)})</span>
            </button>
          );
        })}
      </div>

      {/* Templates List: High Visual Rhythm and Clean Architecture */}
      <div className="flex flex-col gap-2.5 overflow-y-auto max-h-[calc(100vh-340px)] pr-0.5 min-h-[220px]">
        {filteredTemplates.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-850 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700">
            الگویی با این فیلتر یا نام پیدا نشد.
          </div>
        ) : (
          filteredTemplates.map((tpl) => {
            const theme = CATEGORIES[tpl.category] || CATEGORIES.custom;
            const isJustCopied = copiedId === tpl.id;

            return (
              <div
                key={tpl.id}
                draggable
                onDragStart={(e) => handleDragStart(e, tpl)}
                onDragEnd={() => clearGlobalDragState()}
                onDoubleClick={() => onEditTemplate(tpl)}
                className={`group relative p-2.5 sm:p-3 rounded-xl border-2 transition-all duration-150 cursor-grab active:cursor-grabbing hover:-translate-y-0.5 hover:shadow-md ${theme.bgClass} border-slate-300 dark:border-slate-700 dark:bg-slate-850 hover:border-indigo-400 dark:hover:border-indigo-500`}
                title="بکشید و در جدول رها کنید • یا دکمه کپی را بزنید و در هر خانه دلخواه جدول پیست کنید"
              >
                <div className="flex items-start justify-between gap-2">
                  {/* Left: Drag Handle + Category Icon + Title/Subtitle */}
                  <div className="flex items-start gap-2 min-w-0 flex-1">
                    <span className="text-slate-400 group-hover:text-slate-700 dark:text-slate-500 dark:group-hover:text-slate-300 transition-colors mt-0.5 shrink-0" title="دستگیره کشیدن و رها کردن">
                      <GripVertical className="w-4 h-4" />
                    </span>

                    <div
                      className="w-6.5 h-6.5 rounded-lg flex items-center justify-center shrink-0 mt-0.5 border border-black/10 dark:border-white/10 shadow-2xs"
                      style={{ backgroundColor: `${theme.dotColor}25`, color: theme.dotColor }}
                    >
                      <CategoryIcon category={tpl.category} className="w-3.5 h-3.5 stroke-[2.2]" />
                    </div>

                    <div className="min-w-0 flex-1">
                      <h3
                        className="text-xs font-black truncate leading-snug text-slate-900 dark:text-slate-100"
                        title={tpl.title}
                      >
                        {tpl.title}
                      </h3>
                      {tpl.subtitle && (
                        <p className="text-[10px] text-slate-600 dark:text-slate-400 truncate mt-0.5 leading-normal font-medium">
                          {tpl.subtitle}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right: Duration Badge */}
                  <span
                    dir="ltr"
                    className="shrink-0 text-[10.5px] font-mono font-bold px-1.5 py-0.5 rounded-md bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 shadow-2xs leading-none"
                  >
                    {formatDurationFa(tpl.defaultDuration)}
                  </span>
                </div>

                {/* Bottom Row: Quick Add Button & Copy to Clipboard Action */}
                <div className="mt-2.5 pt-2 border-t border-slate-200 dark:border-slate-750 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickAdd(tpl);
                      }}
                      className="flex items-center gap-1 text-[10px] font-bold text-indigo-700 dark:text-indigo-300 hover:text-indigo-900 dark:hover:text-white bg-white dark:bg-slate-750 hover:bg-indigo-50 dark:hover:bg-slate-700 px-2 py-0.5 rounded-md border border-indigo-300 dark:border-indigo-700 transition-all cursor-pointer shadow-2xs"
                      title="افزودن مستقیم به روز جاری یا جدول"
                    >
                      <CalendarPlus className="w-3 h-3" />
                      <span>+ درج سریع</span>
                    </button>

                    {/* Copy to Clipboard Button for 1-click grid pasting */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCopyAction(tpl);
                      }}
                      className={`flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md border transition-all cursor-pointer shadow-2xs ${
                        isJustCopied
                          ? 'bg-emerald-600 text-white border-emerald-700'
                          : 'text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 border-slate-300 dark:border-slate-700'
                      }`}
                      title="کپی این الگو جهت پیست کردن در هر ساعت دلخواه جدول"
                    >
                      {isJustCopied ? (
                        <Check className="w-3 h-3 stroke-[3]" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{isJustCopied ? 'کپی شد!' : 'کپی'}</span>
                    </button>
                  </div>

                  {/* Quick Action Icons */}
                  <div className="flex items-center gap-0.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditTemplate(tpl);
                      }}
                      className="p-1 rounded-md text-slate-500 hover:text-indigo-700 dark:text-slate-400 dark:hover:text-indigo-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                      title="ویرایش مشخصات الگو"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`آیا از حذف الگوی «${tpl.title}» مطمئن هستید؟`)) {
                          onDeleteTemplate(tpl.id);
                        }
                      }}
                      className="p-1 rounded-md text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                      title="حذف الگو"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer with Reset Defaults Option */}
      <div className="pt-2 border-t-2 border-slate-300 dark:border-slate-700 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
        <span className="font-medium">الگوهای تایم‌باکسینگ</span>
        <button
          onClick={() => {
            if (confirm('آیا مایلید الگوها به حالت پیش‌فرض استاندارد بازنشانی شوند؟')) {
              onResetDefaultTemplates();
            }
          }}
          className="flex items-center gap-1 text-[10px] text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-pointer font-bold"
          title="بازنشانی الگوهای پیش‌فرض"
        >
          <RotateCcw className="w-3 h-3" />
          <span>پیش‌فرض‌ها</span>
        </button>
      </div>
    </aside>
  );
};

