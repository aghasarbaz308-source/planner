import React, { useState, useRef, useMemo } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';
import * as htmlToImage from 'html-to-image';
import {
  Printer,
  Download,
  Image,
  Check,
  X,
  Loader2,
  Sparkles,
  Layers,
  ZoomIn,
  ZoomOut,
  Calendar,
  Clock,
  HeartHandshake,
  AlertCircle,
  ListOrdered,
  LayoutGrid,
} from 'lucide-react';
import {
  START_HOUR,
  END_HOUR,
  SLOT_INTERVAL,
  DAYS,
  CATEGORIES,
  getTimePhase,
  minutesToTimeString,
  formatDurationFa,
  toFaDigits,
} from '../constants/plannerConfig';
import { TimeBlock, DayKey, CategoryKey } from '../types';
import {
  alignDayBlocksSequential,
  countWeeklyCollisions,
  resolveAllWeeklyCollisions,
} from '../utils/timeCollisionEngine';

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  blocks: TimeBlock[];
  plannerTitle: string;
  weekRange: string;
  onUpdateBlocks?: (blocks: TimeBlock[]) => void;
}

type PaperSize = 'a4' | 'a3' | 'letter';
type PaperOrientation = 'landscape' | 'portrait';
type RenderQuality = 'ultra' | 'high' | 'standard';
type PrintLayoutMode = 'grid' | 'agenda';

export const PrintModal: React.FC<PrintModalProps> = ({
  isOpen,
  onClose,
  blocks,
  plannerTitle,
  weekRange,
  onUpdateBlocks,
}) => {
  // Config states
  const [paperSize, setPaperSize] = useState<PaperSize>('a4');
  const [orientation, setOrientation] = useState<PaperOrientation>('landscape');
  const [quality, setQuality] = useState<RenderQuality>('ultra');
  const [layoutMode, setLayoutMode] = useState<PrintLayoutMode>('grid');
  const [showLegend, setShowLegend] = useState(true);
  const [showNotesBox, setShowNotesBox] = useState(true);
  const [showStats, setShowStats] = useState(true);
  const [autoAlignPrint, setAutoAlignPrint] = useState<boolean>(true);
  const [previewZoom, setPreviewZoom] = useState<number>(100);

  // Status states
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isGeneratingPng, setIsGeneratingPng] = useState(false);
  const [generationProgress, setGenerationProgress] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const printSheetRef = useRef<HTMLDivElement>(null);

  // Time slots for grid
  const timeSlots = useMemo(() => {
    const slots: { label: string; minutes: number; isHour: boolean }[] = [];
    for (let m = START_HOUR * 60; m < END_HOUR * 60; m += SLOT_INTERVAL) {
      slots.push({
        label: minutesToTimeString(m),
        minutes: m,
        isHour: m % 60 === 0,
      });
    }
    return slots;
  }, []);

  // Summary statistics for printable header
  const stats = useMemo(() => {
    let totalMinutes = 0;
    let deepWorkMinutes = 0;
    let recoveryMinutes = 0;
    let uniMinutes = 0;

    blocks.forEach((b) => {
      totalMinutes += b.durationMinutes;
      if (b.category === 'work' || b.category === 'python' || b.category === 'pytorch') {
        deepWorkMinutes += b.durationMinutes;
      } else if (b.category === 'recovery' || b.category === 'gaming') {
        recoveryMinutes += b.durationMinutes;
      } else if (b.category === 'university') {
        uniMinutes += b.durationMinutes;
      }
    });

    return {
      totalHours: (totalMinutes / 60).toFixed(1),
      deepWorkHours: (deepWorkMinutes / 60).toFixed(1),
      recoveryHours: (recoveryMinutes / 60).toFixed(1),
      uniHours: (uniMinutes / 60).toFixed(1),
      blocksCount: blocks.length,
    };
  }, [blocks]);

  // Weekly overlap count to warn user and allow 1-click resolution
  const weeklyOverlapCount = useMemo(() => {
    return countWeeklyCollisions(blocks);
  }, [blocks]);

  // Dimension calculations for chosen paper size and orientation (Vector-grade crisp layout)
  const sheetDimensions = useMemo(() => {
    if (orientation === 'landscape') {
      if (paperSize === 'a3') return { width: 2480, height: 1754, mmW: 420, mmH: 297 };
      if (paperSize === 'letter') return { width: 1700, height: 1314, mmW: 279.4, mmH: 215.9 };
      // Default A4 Landscape: 1754 x 1240 (Crisp vector ratio 1.414)
      return { width: 1754, height: 1240, mmW: 297, mmH: 210 };
    } else {
      // Portrait
      if (paperSize === 'a3') return { width: 1754, height: 2480, mmW: 297, mmH: 420 };
      if (paperSize === 'letter') return { width: 1314, height: 1700, mmW: 215.9, mmH: 279.4 };
      // Default A4 Portrait: 1240 x 1754
      return { width: 1240, height: 1754, mmW: 210, mmH: 297 };
    }
  }, [paperSize, orientation]);

  // Dynamic slot height to comfortably fit slots without text squishing or micro-overlaps
  const slotHeightPx = useMemo(() => {
    const headerHeight = showStats ? 72 : 52;
    const dayHeaderHeight = 32;
    const footerHeight = showNotesBox ? (showLegend ? 84 : 52) : (showLegend ? 44 : 18);
    const paddingTotal = 28;

    const availableGridHeight =
      sheetDimensions.height - (headerHeight + dayHeaderHeight + footerHeight + paddingTotal);
    const calculatedSlot = Math.floor(availableGridHeight / timeSlots.length);
    return Math.max(calculatedSlot, orientation === 'portrait' ? 38 : 30);
  }, [sheetDimensions.height, showStats, showNotesBox, showLegend, timeSlots.length, orientation]);

  if (!isOpen) return null;

  // Scale multiplier based on chosen quality
  const getScaleMultiplier = () => {
    if (quality === 'ultra') return 3.2; // ~320 DPI ultra crisp print
    if (quality === 'high') return 2.6;  // ~260 DPI crisp print
    return 2.0;                         // ~200 DPI balanced
  };

  // High-fidelity PNG render helper with fallbacks
  const renderElementToDataUrl = async (
    element: HTMLElement,
    scaleMultiplier: number
  ): Promise<string> => {
    try {
      const canvas = await html2canvas(element, {
        scale: scaleMultiplier,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        windowWidth: element.offsetWidth,
        windowHeight: element.offsetHeight,
        onclone: (clonedDoc) => {
          const style = clonedDoc.createElement('style');
          style.innerHTML = `
            * {
              letter-spacing: 0px !important;
              word-spacing: 0px !important;
              font-family: 'Vazirmatn RD', 'Vazirmatn', sans-serif !important;
              font-feature-settings: 'ss01' 1, 'cv01' 1, 'kern' 1, 'liga' 1, 'tnum' 1 !important;
              -webkit-font-smoothing: antialiased !important;
              text-rendering: geometricPrecision !important;
            }
          `;
          clonedDoc.head.appendChild(style);
        },
      });
      return canvas.toDataURL('image/png');
    } catch (primaryErr) {
      console.warn('html2canvas fallback engaged:', primaryErr);
      return await htmlToImage.toPng(element, {
        pixelRatio: scaleMultiplier,
        backgroundColor: '#ffffff',
        style: {
          letterSpacing: '0px',
          fontFamily: "'Vazirmatn RD', 'Vazirmatn', sans-serif",
        },
      });
    }
  };

  // 1. HIGH-QUALITY PDF GENERATION
  const handleExportPDF = async () => {
    if (!printSheetRef.current) return;
    setIsGeneratingPdf(true);
    setErrorMessage(null);
    setGenerationProgress('در حال آماده‌سازی فونت‌ها و رندر عناصر برگه...');

    try {
      if (document.fonts) {
        await document.fonts.ready;
      }
      await new Promise((resolve) => setTimeout(resolve, 150));

      setGenerationProgress('در حال رندر سند چاپی با کیفیت ۳۰۰ DPI بدون تداخل...');
      const element = printSheetRef.current;
      const scaleMultiplier = getScaleMultiplier();

      const imgData = await renderElementToDataUrl(element, scaleMultiplier);

      setGenerationProgress('در حال ساخت سند PDF دقیق در مقیاس برگه استاندارد...');
      const pdf = new jsPDF({
        orientation: orientation,
        unit: 'mm',
        format: paperSize,
        compress: true,
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight, undefined, 'NONE');

      const fileSafeTitle = (plannerTitle || 'Timebox-Planner')
        .replace(/[/\\?%*:|"<>]/g, '-')
        .trim();
      const filename = `${fileSafeTitle}-${paperSize.toUpperCase()}-${orientation}.pdf`;

      setGenerationProgress('دانلود فایل...');
      pdf.save(filename);
      setGenerationProgress('تکمیل شد!');
      setTimeout(() => setGenerationProgress(''), 2000);
    } catch (err: any) {
      console.error('PDF Generation failed:', err);
      setErrorMessage(`خطا در ساخت PDF: ${err?.message || 'مشکل در تبدیل عناصر'}`);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // 2. HIGH-RES PNG EXPORT
  const handleExportPNG = async () => {
    if (!printSheetRef.current) return;
    setIsGeneratingPng(true);
    setErrorMessage(null);
    setGenerationProgress('در حال رندر تصویر با رزولوشن بالا...');

    try {
      if (document.fonts) {
        await document.fonts.ready;
      }
      await new Promise((resolve) => setTimeout(resolve, 150));

      const element = printSheetRef.current;
      const scaleMultiplier = getScaleMultiplier();

      const imageURL = await renderElementToDataUrl(element, scaleMultiplier);

      setGenerationProgress('در حال ذخیره فایل تصویر...');
      const link = document.createElement('a');
      const fileSafeTitle = (plannerTitle || 'Timebox-Planner')
        .replace(/[/\\?%*:|"<>]/g, '-')
        .trim();
      link.download = `${fileSafeTitle}-${paperSize.toUpperCase()}-${orientation}.png`;
      link.href = imageURL;
      link.click();

      setGenerationProgress('تکمیل شد!');
      setTimeout(() => setGenerationProgress(''), 2000);
    } catch (err: any) {
      console.error('PNG Generation failed:', err);
      setErrorMessage(`خطا در تولید تصویر: ${err?.message || 'مشکل در رندر'}`);
    } finally {
      setIsGeneratingPng(false);
    }
  };

  // 3. SAFE BROWSER PRINT TRIGGER
  const handleBrowserPrint = () => {
    setErrorMessage(null);
    try {
      if (printSheetRef.current) {
        const htmlContent = printSheetRef.current.outerHTML;
        const printWindow = window.open('', '_blank');
        if (printWindow) {
          printWindow.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="fa">
              <head>
                <meta charset="utf-8" />
                <title>${plannerTitle || 'برنامه زمانی هفتگی'}</title>
                <style>
                  @page {
                    size: ${paperSize} ${orientation};
                    margin: 0;
                  }
                  body {
                    margin: 0;
                    padding: 0;
                    background: #fff;
                    font-family: 'Vazirmatn', system-ui, sans-serif;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                  }
                  * {
                    box-sizing: border-box;
                    letter-spacing: 0px !important;
                  }
                </style>
              </head>
              <body>
                ${htmlContent}
                <script>
                  window.onload = function() {
                    window.focus();
                    window.print();
                    setTimeout(function() { window.close(); }, 500);
                  };
                </script>
              </body>
            </html>
          `);
          printWindow.document.close();
        } else {
          window.print();
        }
      } else {
        window.print();
      }
    } catch {
      window.print();
    }
  };

  // Mathematical Non-Overlap Layout Engine for Visual Grid
  const getDayBlockLayouts = (dayId: DayKey) => {
    const rawDayBlocks = blocks
      .filter((b) => b.day === dayId)
      .sort((a, b) => {
        if (a.startMinutes !== b.startMinutes) return a.startMinutes - b.startMinutes;
        return b.durationMinutes - a.durationMinutes;
      });

    // When autoAlignPrint is enabled, ensure every block flows sequentially with zero overlap
    const dayBlocks = autoAlignPrint ? alignDayBlocksSequential(rawDayBlocks, 0) : rawDayBlocks;

    // Group overlapping/touching blocks into clusters
    const clusters: TimeBlock[][] = [];
    let currentCluster: TimeBlock[] = [];
    let clusterEnd = -1;

    for (const b of dayBlocks) {
      const bEnd = b.startMinutes + b.durationMinutes;
      if (currentCluster.length === 0) {
        currentCluster.push(b);
        clusterEnd = bEnd;
      } else if (b.startMinutes < clusterEnd) {
        // Overlaps with current cluster
        currentCluster.push(b);
        clusterEnd = Math.max(clusterEnd, bEnd);
      } else {
        clusters.push(currentCluster);
        currentCluster = [b];
        clusterEnd = bEnd;
      }
    }
    if (currentCluster.length > 0) {
      clusters.push(currentCluster);
    }

    // Assign layout coordinates with STRICT mathematical clearance guarantees
    const results: Array<{
      block: TimeBlock;
      topPx: number;
      heightPx: number;
      widthPercent: number;
      leftPercent: number;
      isMicro: boolean;
      isCompact: boolean;
    }> = [];

    const pixelsPerMinute = slotHeightPx / SLOT_INTERVAL;
    const GAP_PX = 2.5;

    clusters.forEach((cluster) => {
      const sortedCluster = [...cluster].sort((a, b) => {
        if (a.startMinutes !== b.startMinutes) return a.startMinutes - b.startMinutes;
        return b.durationMinutes - a.durationMinutes;
      });

      if (sortedCluster.length === 1) {
        const block = sortedCluster[0];
        const topPx = Math.round((block.startMinutes - START_HOUR * 60) * pixelsPerMinute);
        const naturalHeightPx = block.durationMinutes * pixelsPerMinute;

        // Find the next block in the day to bound height strictly
        const globalIdx = dayBlocks.indexOf(block);
        const nextBlock = dayBlocks[globalIdx + 1];
        const nextStart = nextBlock ? nextBlock.startMinutes : END_HOUR * 60;
        const availableMinutes = Math.max(1, nextStart - block.startMinutes);
        const maxClearancePx = availableMinutes * pixelsPerMinute;

        // Absolute guarantee: card height will stop at least GAP_PX before next card
        let safeHeight = Math.min(naturalHeightPx - GAP_PX, maxClearancePx - GAP_PX);
        safeHeight = Math.max(10, Math.round(safeHeight));

        results.push({
          block,
          topPx,
          heightPx: safeHeight,
          widthPercent: 100,
          leftPercent: 0,
          isMicro: safeHeight <= 22,
          isCompact: safeHeight > 22 && safeHeight <= 38,
        });
      } else {
        // Interval coloring for concurrent/overlapping blocks into sub-columns
        const columns: TimeBlock[][] = [];
        const columnEndTimes: number[] = [];

        sortedCluster.forEach((b) => {
          let assignedCol = -1;
          for (let c = 0; c < columnEndTimes.length; c++) {
            if (columnEndTimes[c] <= b.startMinutes) {
              assignedCol = c;
              break;
            }
          }
          if (assignedCol === -1) {
            assignedCol = columnEndTimes.length;
            columns.push([]);
            columnEndTimes.push(0);
          }
          columns[assignedCol].push(b);
          columnEndTimes[assignedCol] = b.startMinutes + b.durationMinutes;
        });

        const totalCols = columns.length;
        const widthPerCol = 100 / totalCols;

        columns.forEach((colBlocks, colIdx) => {
          colBlocks.forEach((block, idxInCol) => {
            const topPx = Math.round((block.startMinutes - START_HOUR * 60) * pixelsPerMinute);
            const naturalHeightPx = block.durationMinutes * pixelsPerMinute;

            const nextBlockInCol = colBlocks[idxInCol + 1];
            const nextStart = nextBlockInCol ? nextBlockInCol.startMinutes : END_HOUR * 60;
            const availableMinutes = Math.max(1, nextStart - block.startMinutes);
            const maxClearancePx = availableMinutes * pixelsPerMinute;

            let safeHeight = Math.min(naturalHeightPx - GAP_PX, maxClearancePx - GAP_PX);
            safeHeight = Math.max(10, Math.round(safeHeight));

            results.push({
              block,
              topPx,
              heightPx: safeHeight,
              widthPercent: widthPerCol - 1.2,
              leftPercent: colIdx * widthPerCol,
              isMicro: safeHeight <= 22,
              isCompact: safeHeight > 22 && safeHeight <= 38,
            });
          });
        });
      }
    });

    return results;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-7xl bg-white rounded-3xl shadow-2xl border border-slate-300 overflow-hidden flex flex-col h-[95vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
        dir="rtl"
      >
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-gradient-to-l from-slate-900 via-indigo-950 to-slate-900 text-white shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300 shadow-inner">
              <Printer className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                <span>مرکز چاپ و خروجی باکیفیت (PDF & Print Engine)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-mono font-bold">
                  Zero-Overlap Math
                </span>
              </h2>
              <p className="text-[11.5px] text-slate-300 mt-0.5">
                تولید مستقیم سند استاندارد A4 بدون هیچ‌گونه تداخل یا روی‌هم‌افتادگی کارت‌های زمانی
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar & Print Settings Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-2.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Toggle: Grid vs Agenda */}
            <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5 shadow-2xs">
              <button
                type="button"
                onClick={() => setLayoutMode('grid')}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                  layoutMode === 'grid'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="جدول بصری ۷ روزه با فاصله‌گذاری هندسی ضد تداخل"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>جدول زمانی (Visual Grid)</span>
              </button>
              <button
                type="button"
                onClick={() => setLayoutMode('agenda')}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                  layoutMode === 'agenda'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="فهرست منظم و خطی روزانه برای کلیپ‌بورد و خودکار"
              >
                <ListOrdered className="w-3.5 h-3.5" />
                <span>دستورکار تفکیکی (Agenda)</span>
              </button>
            </div>

            {/* Paper Size */}
            <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5 shadow-2xs">
              {(['a4', 'a3', 'letter'] as PaperSize[]).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => setPaperSize(size)}
                  className={`px-2.5 py-1 text-xs font-mono font-bold rounded-lg transition-colors cursor-pointer ${
                    paperSize === size
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {size.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Orientation */}
            <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5 shadow-2xs">
              <button
                type="button"
                onClick={() => setOrientation('landscape')}
                className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  orientation === 'landscape'
                    ? 'bg-slate-900 text-white font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                افقی (Landscape)
              </button>
              <button
                type="button"
                onClick={() => setOrientation('portrait')}
                className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  orientation === 'portrait'
                    ? 'bg-slate-900 text-white font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                عمودی (Portrait)
              </button>
            </div>

            {/* Resolution Quality */}
            <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5 shadow-2xs">
              <button
                type="button"
                onClick={() => setQuality('ultra')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  quality === 'ultra'
                    ? 'bg-emerald-700 text-white font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="رزولوشن فوق‌العاده بالا ۳۰۰ DPI مخصوص چاپ"
              >
                ۳۰۰ DPI
              </button>
              <button
                type="button"
                onClick={() => setQuality('high')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  quality === 'high'
                    ? 'bg-emerald-700 text-white font-bold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                ۲۰۰ DPI
              </button>
            </div>
          </div>

          {/* Right Controls: Content Toggles & Preview Zoom */}
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1.5 text-xs text-slate-700 bg-white border border-slate-200 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-slate-50 shadow-2xs select-none">
              <input
                type="checkbox"
                checked={showLegend}
                onChange={(e) => setShowLegend(e.target.checked)}
                className="w-3.5 h-3.5 text-indigo-600 rounded-sm"
              />
              <span>راهنمای رنگ‌ها</span>
            </label>

            <label className="flex items-center gap-1.5 text-xs text-slate-700 bg-white border border-slate-200 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-slate-50 shadow-2xs select-none">
              <input
                type="checkbox"
                checked={showNotesBox}
                onChange={(e) => setShowNotesBox(e.target.checked)}
                className="w-3.5 h-3.5 text-indigo-600 rounded-sm"
              />
              <span>کادر یادداشت</span>
            </label>

            <label className="flex items-center gap-1.5 text-xs text-indigo-900 bg-indigo-50/80 border border-indigo-200 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-indigo-100/70 shadow-2xs select-none font-bold">
              <input
                type="checkbox"
                checked={autoAlignPrint}
                onChange={(e) => setAutoAlignPrint(e.target.checked)}
                className="w-3.5 h-3.5 text-indigo-600 rounded-sm"
              />
              <span className="flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                <span>تراز ضد تداخل</span>
              </span>
            </label>

            {/* Preview Zoom Controls */}
            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl p-1 shadow-2xs text-xs text-slate-600">
              <button
                type="button"
                onClick={() => setPreviewZoom((z) => Math.max(z - 15, 40))}
                className="p-1 hover:bg-slate-100 rounded-md cursor-pointer"
                title="کوچک‌نمایی"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="w-11 text-center font-mono font-semibold">
                {previewZoom}%
              </span>
              <button
                type="button"
                onClick={() => setPreviewZoom((z) => Math.min(z + 15, 150))}
                className="p-1 hover:bg-slate-100 rounded-md cursor-pointer"
                title="بزرگ‌نمایی"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setPreviewZoom(100)}
                className="px-1.5 py-0.5 text-[10px] font-semibold text-indigo-600 hover:bg-indigo-50 rounded-md cursor-pointer"
              >
                ۱۰۰٪
              </button>
            </div>
          </div>
        </div>

        {/* Anti-collision status / 1-click resolver banner */}
        {weeklyOverlapCount > 0 && (
          <div className="bg-amber-500/10 border-b border-amber-500/20 px-5 py-2 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
            <div className="flex items-center gap-2 text-amber-800 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0 animate-pulse" />
              <span>
                در داده‌های این هفته <strong>{toFaDigits(weeklyOverlapCount)} مورد هم‌پوشانی زمانی</strong> شناسایی شد.
                {autoAlignPrint ? ' (موتور تراز هوشمند فعال است و در برگه چاپی کارت‌ها بدون تداخل و با دقت هندسی قرار می‌گیرند)' : ''}
              </span>
            </div>
            {onUpdateBlocks && (
              <button
                type="button"
                onClick={() => {
                  const resolved = resolveAllWeeklyCollisions(blocks);
                  onUpdateBlocks(resolved);
                }}
                className="flex items-center gap-1.5 px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>رفع دائمی تداخل‌ها در دیتابیس هفته</span>
              </button>
            )}
          </div>
        )}

        {/* Error message banner */}
        {errorMessage && (
          <div className="bg-rose-50 border-b border-rose-200 px-4 py-2 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Main Printable Canvas Area (Visual Interactive Preview) */}
        <div className="flex-1 bg-slate-200/80 p-4 sm:p-6 overflow-auto flex justify-center items-start">
          <div
            style={{
              transform: `scale(${previewZoom / 100})`,
              transformOrigin: 'top center',
              transition: 'transform 0.15s ease-out',
            }}
            className="shrink-0 shadow-2xl rounded-sm overflow-hidden"
          >
            {/* The Actual Printable Sheet Component captured by html2canvas */}
            <div
              ref={printSheetRef}
              style={{
                width: `${sheetDimensions.width}px`,
                height: `${sheetDimensions.height}px`,
                letterSpacing: '0px',
                fontFamily: "'Vazirmatn RD', 'Vazirmatn', system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
                fontFeatureSettings: "'ss01' 1, 'cv01' 1, 'kern' 1, 'liga' 1, 'tnum' 1",
                backgroundColor: '#ffffff',
              }}
              className="bg-white text-slate-900 border border-slate-300 flex flex-col p-4 box-border overflow-hidden select-none"
              dir="rtl"
            >
              {/* Printable Sheet Header */}
              <div className="flex items-center justify-between border-b-2 border-slate-800 pb-2 mb-2 shrink-0 gap-3">
                <div className="flex items-center gap-3 min-w-0 flex-1 max-w-[62%]">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 text-white flex items-center justify-center font-bold shadow-xs shrink-0">
                    <Clock className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h1
                        style={{ letterSpacing: '0px' }}
                        className="text-base sm:text-lg font-extrabold text-slate-950 leading-normal truncate"
                      >
                        {plannerTitle || 'برنامه‌ریز هفتگی تایم‌باکسینگ'}
                      </h1>
                      <span className="text-[10px] px-2 py-0.5 rounded-sm bg-slate-900 text-white font-mono font-bold shrink-0">
                        ANTI-FRAGILE
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-sm bg-indigo-50 border border-indigo-200 text-indigo-800 font-bold shrink-0">
                        {paperSize.toUpperCase()} {orientation === 'landscape' ? 'افقی' : 'عمودی'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-600 mt-0.5 min-w-0">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-medium truncate">
                        {weekRange || 'برنامه هفتگی کار عمیق، یادگیری، دانشگاه و ریکاوری'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right Header: Motivational & Stats */}
                <div className="flex flex-col items-end gap-1 shrink-0 max-w-[38%]">
                  <div className="flex items-center gap-1 text-[11px] bg-teal-50 border border-teal-200 text-teal-900 px-2.5 py-1 rounded-lg">
                    <HeartHandshake className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                    <span className="font-semibold truncate">
                      «۱ همیشه از ۰ بزرگ‌تره - در صورت تأخیر، بدون سرزنش شیفت بده!»
                    </span>
                  </div>

                  {showStats && (
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5 flex-wrap justify-end">
                      <span>
                        کل زمان:{' '}
                        <strong className="text-slate-800 font-mono">
                          {toFaDigits(stats.totalHours)}س
                        </strong>
                      </span>
                      <span className="text-slate-300">•</span>
                      <span>
                        تمرکز عمیق:{' '}
                        <strong className="text-sky-700 font-mono">
                          {toFaDigits(stats.deepWorkHours)}س
                        </strong>
                      </span>
                      <span className="text-slate-300">•</span>
                      <span>
                        ریکاوری:{' '}
                        <strong className="text-emerald-700 font-mono">
                          {toFaDigits(stats.recoveryHours)}س
                        </strong>
                      </span>
                      <span className="text-slate-300">•</span>
                      <span>
                        چاپ:{' '}
                        <strong className="text-slate-700 font-mono">
                          {new Date().toLocaleDateString('fa-IR')}
                        </strong>
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* MODE 1: VISUAL GRID VIEW WITH NON-OVERLAP MATH */}
              {layoutMode === 'grid' && (
                <div className="border border-slate-300 w-full shrink-0 flex flex-col box-border">
                  {/* Days Header Row */}
                  <div className="grid grid-cols-[70px_repeat(7,1fr)] border-b border-slate-300 shrink-0 text-center select-none">
                    <div className="py-1 px-1 border-l border-slate-300 text-[10px] font-black text-slate-700 bg-slate-100 flex items-center justify-center gap-1">
                      <Clock className="w-3 h-3 text-indigo-600" />
                      <span>خط زمان</span>
                    </div>
                    {DAYS.map((day) => (
                      <div
                        key={day.id}
                        style={{ backgroundColor: day.printHeaderBg }}
                        className="py-1 px-1 border-l last:border-l-0 border-slate-300 flex flex-col items-center justify-center"
                      >
                        <div className="flex items-center justify-center gap-1">
                          <span
                            className="w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: day.dotColor }}
                          />
                          <span className="text-xs font-black text-slate-900 leading-normal">
                            {day.nameFa}
                          </span>
                          <span className="text-[9px] text-slate-500 font-medium">
                            ({day.nameEn})
                          </span>
                        </div>
                        <span className="text-[8px] font-bold text-slate-600 mt-0.5 leading-normal">
                          {day.mood}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Grid Canvas & Time Slots & Blocks */}
                  <div
                    style={{
                      height: `${timeSlots.length * slotHeightPx}px`,
                    }}
                    className="grid grid-cols-[70px_repeat(7,1fr)] relative bg-white shrink-0 overflow-hidden"
                  >
                    {/* Time labels column */}
                    <div className="border-l border-slate-300 bg-slate-50/50 select-none">
                      {timeSlots.map((slot) => {
                        const hour = Math.floor(slot.minutes / 60);
                        const phase = getTimePhase(hour);

                        if (slot.isHour) {
                          return (
                            <div
                              key={slot.minutes}
                              style={{ height: `${slotHeightPx}px` }}
                              className="relative flex items-center justify-between px-1.5 font-mono border-b border-slate-300 bg-slate-100/60"
                            >
                              <div
                                className="absolute right-0 inset-y-0 w-[3px]"
                                style={{ backgroundColor: phase.color }}
                              />
                              <span
                                className="text-[7px] font-bold px-0.5 rounded leading-normal truncate max-w-[28px]"
                                style={{ color: phase.color }}
                              >
                                {hour === phase.startHour ? phase.nameFa.slice(0, 6) : ''}
                              </span>
                              <span className="font-bold text-[10px] text-slate-900">
                                {toFaDigits(slot.label)}
                              </span>
                            </div>
                          );
                        }

                        return (
                          <div
                            key={slot.minutes}
                            style={{ height: `${slotHeightPx}px` }}
                            className="relative flex items-center justify-end pr-2 font-mono border-b border-slate-150 text-[9px] text-slate-400"
                          >
                            <div
                              className="absolute right-0 inset-y-0 w-[1.5px] opacity-40"
                              style={{ backgroundColor: phase.color }}
                            />
                            ۳۰:
                          </div>
                        );
                      })}
                    </div>

                    {/* 7 Days Columns with rendered blocks */}
                    {DAYS.map((day) => {
                      const dayLayouts = getDayBlockLayouts(day.id);

                      return (
                        <div
                          key={day.id}
                          className="relative border-l last:border-l-0 border-slate-300 bg-white"
                          style={{
                            height: `${timeSlots.length * slotHeightPx}px`,
                          }}
                        >
                          {/* Grid background lines */}
                          {timeSlots.map((slot) => (
                            <div
                              key={slot.minutes}
                              style={{ height: `${slotHeightPx}px` }}
                              className={`border-b ${
                                slot.isHour ? 'border-slate-200' : 'border-slate-100'
                              }`}
                            />
                          ))}

                          {/* Rendered Time Blocks with zero-overlap guarantees */}
                          {dayLayouts.map(({ block, topPx, heightPx, widthPercent, leftPercent, isMicro, isCompact }) => {
                            const theme = CATEGORIES[block.category] || CATEGORIES.custom;
                            const startStr = minutesToTimeString(block.startMinutes);
                            const endStr = minutesToTimeString(block.startMinutes + block.durationMinutes);
                            const timeRange = `${toFaDigits(startStr)} - ${toFaDigits(endStr)}`;

                            return (
                              <div
                                key={block.id}
                                style={{
                                  top: `${topPx}px`,
                                  height: `${heightPx}px`,
                                  width: `${widthPercent}%`,
                                  right: `${leftPercent}%`,
                                  backgroundColor: theme.printBg,
                                  borderColor: theme.printBorder,
                                  color: theme.printText,
                                }}
                                className="absolute rounded-xs border overflow-hidden shadow-2xs box-border z-10"
                              >
                                {isMicro ? (
                                  /* Micro layout for 15-20 min blocks */
                                  <div className="flex items-center justify-between h-full px-1 overflow-hidden box-border leading-none gap-1">
                                    <div className="flex items-center gap-1 min-w-0 flex-1 overflow-hidden">
                                      <span
                                        className="w-1.5 h-1.5 rounded-full shrink-0"
                                        style={{ backgroundColor: theme.dotColor }}
                                      />
                                      <span
                                        className="text-[7.5px] font-bold truncate leading-none min-w-0 flex-1"
                                        style={{ color: theme.printText, letterSpacing: '0px' }}
                                      >
                                        {block.title}
                                      </span>
                                    </div>
                                    <span
                                      className="text-[6.5px] px-1 py-0.2 rounded-2xs font-mono font-bold shrink-0 bg-white/90"
                                      style={{ color: theme.printText }}
                                    >
                                      {toFaDigits(startStr)}
                                    </span>
                                  </div>
                                ) : isCompact ? (
                                  /* Compact layout for 25-40 min blocks */
                                  <div className="flex items-center justify-between h-full px-1.5 gap-1 overflow-hidden box-border">
                                    <div className="flex items-center gap-1 min-w-0 flex-1 overflow-hidden">
                                      {block.completed ? (
                                        <span className="w-2.5 h-2.5 rounded-xs bg-emerald-700 text-white flex items-center justify-center shrink-0">
                                          <Check className="w-2 h-2 stroke-[3]" />
                                        </span>
                                      ) : (
                                        <span
                                          className="w-1.5 h-1.5 rounded-full shrink-0"
                                          style={{ backgroundColor: theme.dotColor }}
                                        />
                                      )}
                                      <h4
                                        className={`text-[8.5px] font-bold truncate leading-none min-w-0 flex-1 ${
                                          block.completed ? 'line-through opacity-70' : ''
                                        }`}
                                        style={{ color: theme.printText, letterSpacing: '0px' }}
                                      >
                                        {block.title}
                                      </h4>
                                    </div>
                                    <span
                                      className="text-[7.5px] px-1 py-0.2 rounded-xs font-mono font-bold shrink-0 bg-white/90"
                                      style={{ color: theme.printText }}
                                    >
                                      {timeRange}
                                    </span>
                                  </div>
                                ) : (
                                  /* Full card for longer blocks */
                                  <div className="flex flex-col justify-between h-full p-1 overflow-hidden box-border">
                                    <div className="flex items-center justify-between gap-1 w-full min-w-0 shrink-0">
                                      <div className="flex items-center gap-1 min-w-0 flex-1">
                                        {block.completed ? (
                                          <span className="w-3 h-3 rounded-xs bg-emerald-700 text-white flex items-center justify-center shrink-0">
                                            <Check className="w-2 h-2 stroke-[3]" />
                                          </span>
                                        ) : (
                                          <span
                                            className="w-1.5 h-1.5 rounded-full shrink-0"
                                            style={{ backgroundColor: theme.dotColor }}
                                          />
                                        )}
                                        <h4
                                          className={`text-[9px] font-bold leading-snug truncate min-w-0 flex-1 ${
                                            block.completed ? 'line-through opacity-70' : ''
                                          }`}
                                          style={{ color: theme.printText, letterSpacing: '0px' }}
                                        >
                                          {block.title}
                                        </h4>
                                      </div>

                                      <span
                                        className="text-[7.5px] px-1 py-0.2 rounded-xs font-mono font-bold shrink-0 bg-white/90"
                                        style={{ color: theme.printText }}
                                      >
                                        {timeRange}
                                      </span>
                                    </div>

                                    {heightPx >= 48 && block.subtitle && (
                                      <div className="my-auto min-w-0 overflow-hidden">
                                        <p
                                          className="text-[8px] opacity-90 truncate leading-snug"
                                          style={{ letterSpacing: '0px' }}
                                        >
                                          {block.subtitle}
                                        </p>
                                      </div>
                                    )}

                                    {heightPx >= 42 && (
                                      <div className="flex items-center justify-between text-[8px] opacity-80 pt-0.5 border-t border-black/10 mt-auto shrink-0">
                                        <span className="truncate">{theme.label}</span>
                                        <span className="font-mono font-bold shrink-0">
                                          {formatDurationFa(block.durationMinutes)}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* MODE 2: DAY-BY-DAY AGENDA LIST (CLEAN PRINTABLE TABLE) */}
              {layoutMode === 'agenda' && (
                <div className="flex-1 overflow-hidden grid grid-cols-7 gap-2 border border-slate-300 p-2 rounded-sm bg-slate-50/50">
                  {DAYS.map((day) => {
                    const dayBlocks = blocks
                      .filter((b) => b.day === day.id)
                      .sort((a, b) => a.startMinutes - b.startMinutes);

                    return (
                      <div
                        key={day.id}
                        className="bg-white border border-slate-300 rounded-sm flex flex-col overflow-hidden"
                      >
                        {/* Day Column Header */}
                        <div
                          style={{ backgroundColor: day.printHeaderBg }}
                          className="px-2 py-1.5 border-b border-slate-300 flex items-center justify-between text-xs"
                        >
                          <span className="font-black text-slate-900">{day.nameFa}</span>
                          <span className="text-[10px] font-mono text-slate-500">
                            {toFaDigits(dayBlocks.length)} تسک
                          </span>
                        </div>

                        {/* Tasks List */}
                        <div className="flex-1 p-1.5 overflow-hidden space-y-1 text-slate-800">
                          {dayBlocks.length === 0 ? (
                            <div className="h-full flex items-center justify-center text-[10px] text-slate-400 font-medium">
                              بدون تسک
                            </div>
                          ) : (
                            dayBlocks.map((b) => {
                              const theme = CATEGORIES[b.category] || CATEGORIES.custom;
                              const startStr = minutesToTimeString(b.startMinutes);
                              const endStr = minutesToTimeString(b.startMinutes + b.durationMinutes);

                              return (
                                <div
                                  key={b.id}
                                  style={{
                                    backgroundColor: theme.printBg,
                                    borderColor: theme.printBorder,
                                    color: theme.printText,
                                  }}
                                  className="p-1 rounded-xs border text-[9px] flex flex-col gap-0.5"
                                >
                                  <div className="flex items-center justify-between gap-1">
                                    <span className="font-mono font-bold text-[8px] bg-white/90 px-1 rounded-2xs">
                                      {toFaDigits(startStr)} - {toFaDigits(endStr)}
                                    </span>
                                    <span className="font-mono text-[7.5px] opacity-75">
                                      {formatDurationFa(b.durationMinutes)}
                                    </span>
                                  </div>
                                  <div className="font-bold truncate leading-tight mt-0.5">
                                    {b.title}
                                  </div>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Printable Footer Section */}
              <div className="mt-2 pt-2 border-t border-slate-300 flex flex-col gap-1.5 shrink-0">
                {showLegend && (
                  <div className="flex flex-wrap items-center justify-between gap-1.5 px-2 py-1 bg-slate-50 border border-slate-200 rounded-md text-[9px]">
                    <span className="font-bold text-slate-700 shrink-0">
                      راهنمای رنگ‌ها:
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      {Object.values(CATEGORIES).map((cat) => (
                        <div key={cat.key} className="flex items-center gap-1">
                          <span
                            className="w-2.5 h-2.5 rounded-xs border shrink-0"
                            style={{
                              backgroundColor: cat.printBg,
                              borderColor: cat.printBorder,
                            }}
                          />
                          <span className="text-slate-700 font-medium">
                            {cat.label}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {showNotesBox && (
                  <div className="grid grid-cols-3 gap-2 px-2 py-1.5 bg-slate-50/70 border border-dashed border-slate-300 rounded-md text-[9.5px]">
                    <div className="border-l border-slate-200 pl-2">
                      <span className="font-bold text-slate-800">
                        ۳ اولویت اصلی هفته (MITs):
                      </span>
                      <div className="mt-1 space-y-1 text-slate-400 font-mono">
                        <div>۱. ................................................................</div>
                        <div>۲. ................................................................</div>
                      </div>
                    </div>

                    <div className="border-l border-slate-200 pl-2">
                      <span className="font-bold text-slate-800">
                        یادداشت ضد شکنندگی و تطبیق:
                      </span>
                      <p className="text-[8.5px] text-slate-600 mt-1 leading-relaxed">
                        اگر بخشی از زمان به تعویق افتاد، به جای سرزنش خود، بلوک بعدی را با آرامش آغاز کنید. پیروزی در تداوم است!
                      </p>
                    </div>

                    <div>
                      <span className="font-bold text-slate-800">
                        ارزیابی پایان هفته:
                      </span>
                      <div className="mt-1 space-y-1 text-slate-400 font-mono">
                        <div>میزان پایبندی: [ ] عالی [ ] خوب [ ] نیاز به تنظیم</div>
                        <div>بزرگ‌ترین موفقیت: .......................................</div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between text-[8px] text-slate-400 px-1 font-mono">
                  <span>
                    سیستم برنامه‌ریزی ضد شکنندگی تایم‌باکسینگ (Anti-Fragile Timeboxing)
                  </span>
                  <span>
                    اندازه برگه: {paperSize.toUpperCase()} {orientation === 'landscape' ? 'افقی' : 'عمودی'} | چاپ بدون تداخل
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Action Footer */}
        <div className="bg-white border-t border-slate-200 px-5 py-3 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            {generationProgress ? (
              <div className="flex items-center gap-2 text-indigo-600 font-medium">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{generationProgress}</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-slate-500">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>
                  برگه خروجی کاملاً در ابعاد دقیق {paperSize.toUpperCase()} {orientation === 'landscape' ? 'افقی' : 'عمودی'} بدون تداخل کارت‌های کوتاه رندر و دانلود می‌شود.
                </span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleBrowserPrint}
              id="browser-print-btn"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-600" />
              <span>چاپ با مرورگر</span>
            </button>

            <button
              type="button"
              onClick={handleExportPNG}
              disabled={isGeneratingPng || isGeneratingPdf}
              id="export-png-btn"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer disabled:opacity-50"
            >
              {isGeneratingPng ? (
                <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
              ) : (
                <Image className="w-4 h-4 text-slate-600" />
              )}
              <span>دانلود عکس (PNG)</span>
            </button>

            <button
              type="button"
              onClick={handleExportPDF}
              disabled={isGeneratingPdf || isGeneratingPng}
              id="download-pdf-btn"
              className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md hover:shadow-lg transition-all cursor-pointer disabled:opacity-50"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>در حال ساخت PDF...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-white" />
                  <span>دانلود فایل PDF (کیفیت چاپی عالی)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
