import React, { useRef } from 'react';
import {
  Clock,
  Printer,
  Sparkles,
  Zap,
  BarChart3,
  Calendar,
  Trash2,
  HeartHandshake,
  FileText,
  Code2,
  Laptop,
  Maximize2,
  Minimize2,
  BrainCircuit,
  Database,
  ShieldCheck,
  Moon,
  Sun,
  Undo2,
  Redo2,
  Film,
} from 'lucide-react';
import { MOTIVATIONAL_QUOTES, toFaDigits } from '../constants/plannerConfig';

interface HeaderProps {
  plannerTitle: string;
  onUpdateTitle: (newTitle: string) => void;
  weekRange: string;
  onUpdateWeekRange: (newRange: string) => void;
  onSaveJSON: () => void;
  onLoadJSON: (file: File) => void;
  onPrint: () => void;
  onOpenDailyReport: () => void;
  onOpenSpecialReport: () => void;
  onOpenJsonModal: () => void;
  onOpenOfflineExport: () => void;
  onResetSample: () => void;
  onClearAll: () => void;
  onOpenLateShift: () => void;
  onOpenSleepMovie?: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
  undoCount?: number;
  redoCount?: number;
  onToggleStats: () => void;
  showStats: boolean;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
  onOpenCircadian?: () => void;
  onOpenDatabase?: () => void;
  onOpenPlannerRules?: () => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  plannerTitle,
  onUpdateTitle,
  weekRange,
  onUpdateWeekRange,
  onSaveJSON,
  onLoadJSON,
  onPrint,
  onOpenDailyReport,
  onOpenSpecialReport,
  onOpenJsonModal,
  onOpenOfflineExport,
  onResetSample,
  onClearAll,
  onOpenLateShift,
  onOpenSleepMovie,
  onUndo,
  onRedo,
  canUndo = false,
  canRedo = false,
  undoCount = 0,
  redoCount = 0,
  onToggleStats,
  showStats,
  isFullscreen = false,
  onToggleFullscreen,
  onOpenCircadian,
  onOpenDatabase,
  onOpenPlannerRules,
  darkMode = false,
  onToggleDarkMode,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onLoadJSON(file);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <header className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/90 dark:border-slate-800 sticky top-0 z-30 shadow-xs no-print transition-all">
      {/* Psychological Reassurance Banner */}
      <div className="bg-gradient-to-r from-emerald-50/90 via-teal-50/70 to-indigo-50/80 dark:from-emerald-950/40 dark:via-teal-950/30 dark:to-indigo-950/40 border-b border-teal-100 dark:border-teal-900/50 px-4 py-1.5 text-xs text-teal-950 dark:text-teal-200 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 max-w-4xl min-w-0">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-teal-200/70 dark:bg-teal-800/60 text-teal-800 dark:text-teal-200 shadow-2xs">
            <HeartHandshake className="w-3.5 h-3.5" />
          </span>
          <p className="font-medium leading-relaxed truncate md:whitespace-normal text-[11px] sm:text-xs">
            <span className="font-black text-teal-950 dark:text-teal-100">قانون ضد شکنندگی: </span>
            {MOTIVATIONAL_QUOTES[0]}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {onOpenSleepMovie && (
            <button
              onClick={onOpenSleepMovie}
              id="quick-sleep-movie-btn"
              className="flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs shadow-2xs transition-colors cursor-pointer shrink-0"
              title="چینش خودکار زمان خواب شبانه، چرت نیمروزی و سانس‌های فیلم در کل هفته"
            >
              <Moon className="w-3.5 h-3.5 text-indigo-200" />
              <span>چینش خودکار خواب و فیلم</span>
            </button>
          )}
          <button
            onClick={onOpenLateShift}
            id="quick-shift-btn"
            className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg text-xs shadow-2xs transition-colors cursor-pointer shrink-0"
            title="هل دادن سریع بلوک‌ها به بعد در صورت بیدار شدن دیروقت"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>دیر بیدار شدم! (شیفت روز)</span>
          </button>
        </div>
      </div>

      {/* Main Topbar */}
      <div className="max-w-[1850px] mx-auto px-4 py-2.5 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        {/* Title & Week descriptor */}
        <div className="flex items-center gap-3 min-w-0 flex-1 max-w-2xl">
          <div className="w-10 h-10 rounded-2xl bg-slate-900 dark:bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0 ring-4 ring-slate-100 dark:ring-slate-800">
            <Clock className="w-5 h-5 text-indigo-400 dark:text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
              <input
                type="text"
                value={plannerTitle}
                onChange={(e) => onUpdateTitle(e.target.value)}
                aria-label="عنوان برنامه‌ریز"
                className="font-black text-slate-900 dark:text-white text-base md:text-lg bg-transparent hover:bg-slate-100/70 dark:hover:bg-slate-800/70 focus:bg-white dark:focus:bg-slate-800 px-2 py-0.5 rounded-lg border border-transparent focus:border-slate-300 dark:focus:border-slate-700 focus:outline-hidden transition-colors w-full sm:max-w-md md:max-w-lg truncate focus:overflow-visible leading-normal"
                title="برای ویرایش عنوان کلیک کنید"
              />
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 font-bold shrink-0">
                Anti-Fragile v2
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5 min-w-0">
              <Calendar className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
              <input
                type="text"
                value={weekRange}
                onChange={(e) => onUpdateWeekRange(e.target.value)}
                placeholder="مثلا: هفته اول اسپرینت | تمرکز روی پایتورچ و لینوکس"
                aria-label="بازه زمانی هفته"
                className="text-xs text-slate-600 dark:text-slate-300 bg-transparent hover:bg-slate-100/70 dark:hover:bg-slate-800/70 focus:bg-white dark:focus:bg-slate-800 px-2 py-0.5 rounded-md border border-transparent focus:border-slate-300 dark:focus:border-slate-700 focus:outline-hidden w-full sm:max-w-md truncate focus:overflow-visible leading-normal font-medium"
                title="برای ویرایش بازه زمانی کلیک کنید"
              />
            </div>
          </div>
        </div>

        {/* Organized Functional Action Groups */}
        <div className="flex flex-wrap items-center gap-2 md:gap-2.5">
          {/* GROUP 0: High-Precision Undo / Redo Multi-Step Controls */}
          {onUndo && (
            <div className="flex items-center gap-1 p-1 bg-slate-100/80 dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700">
              <button
                type="button"
                onClick={onUndo}
                disabled={!canUndo}
                id="header-undo-btn"
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  canUndo
                    ? 'text-slate-800 dark:text-slate-100 hover:bg-white dark:hover:bg-slate-700 hover:text-indigo-600 cursor-pointer shadow-2xs'
                    : 'text-slate-300 dark:text-slate-600 cursor-not-allowed opacity-40'
                }`}
                title="بازگشت به مرحله قبل (Ctrl + Z)"
              >
                <Undo2 className="w-3.5 h-3.5" />
                <span>بازگشت</span>
                {canUndo && undoCount > 0 && (
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded-md bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-black">
                    {toFaDigits(undoCount)}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={onRedo}
                disabled={!canRedo}
                id="header-redo-btn"
                className={`flex items-center gap-1 p-1.5 rounded-xl text-xs font-bold transition-all ${
                  canRedo
                    ? 'text-slate-800 dark:text-slate-100 hover:bg-white dark:hover:bg-slate-700 hover:text-indigo-600 cursor-pointer shadow-2xs'
                    : 'text-slate-300 dark:text-slate-600 cursor-not-allowed opacity-40'
                }`}
                title="انجام مجدد مرحله (Ctrl + Y)"
              >
                <Redo2 className="w-3.5 h-3.5" />
                {canRedo && redoCount > 0 && (
                  <span className="text-[9px] font-mono px-1 py-0.2 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold">
                    {toFaDigits(redoCount)}
                  </span>
                )}
              </button>
            </div>
          )}

          {/* GROUP 1: Primary Intelligence & Views */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100/80 dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700">
            {/* Auto Sleep & Movie Scheduler */}
            {onOpenSleepMovie && (
              <button
                onClick={onOpenSleepMovie}
                id="header-sleep-movie-btn"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-slate-600 text-indigo-900 dark:text-indigo-200 border border-slate-200/80 dark:border-slate-600 hover:border-indigo-300 shadow-2xs transition-all cursor-pointer"
                title="چینش اتوماتیک زمان خواب عمیق شبانه، چرت نیمروزی و سانس فیلم در طول هفته"
              >
                <Moon className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>خواب و فیلم</span>
              </button>
            )}

            {/* SPECIAL WEEKLY REPORT */}
            <button
              onClick={onOpenSpecialReport}
              id="special-weekly-report-btn"
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm transition-all cursor-pointer hover:shadow-indigo-500/25"
              title="گزارش ویژه از هر کارت، ساعات پایتون/پایتورچ، درصد سهم و هوش تحلیلی هفتگی"
            >
              <BrainCircuit className="w-4 h-4 stroke-[2.2]" />
              <span>گزارش ویژه هفتگی</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-white/20 text-white font-mono font-bold">
                تحلیلی
              </span>
            </button>

            {/* Daily Report */}
            <button
              onClick={onOpenDailyReport}
              id="daily-report-btn"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-700 hover:bg-emerald-50 dark:hover:bg-slate-600 text-emerald-800 dark:text-emerald-300 border border-slate-200/80 dark:border-slate-600 hover:border-emerald-300 shadow-2xs transition-all cursor-pointer"
              title="گزارش روزانه متنی و صدور کارت تصویری باکیفیت بالا (PNG)"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>گزارش روزانه</span>
            </button>

            {/* Dedicated Monitor Fullscreen */}
            {onToggleFullscreen && (
              <button
                onClick={onToggleFullscreen}
                id="header-fullscreen-btn"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                  isFullscreen
                    ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-600 shadow-2xs'
                    : 'bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-600 shadow-2xs'
                }`}
                title="مشاهده تمام‌صفحه اختصاصی جدول برنامه متناسب با مانیتور بدون سایدبار (کلید F)"
              >
                {isFullscreen ? (
                  <>
                    <Minimize2 className="w-3.5 h-3.5 text-white" />
                    <span>خروج تمام‌صفحه</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
                    <span>تمام‌صفحه مانیتور</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* GROUP 2: Exports & Print */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100/80 dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700">
            {/* Print A4 / PDF */}
            <button
              onClick={onPrint}
              id="print-a4-btn"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-900 dark:bg-slate-950 hover:bg-slate-800 text-white shadow-2xs transition-all cursor-pointer"
              title="چاپ هفتگی A4 و A3 یا دانلود مستقیم PDF با کیفیت بالا"
            >
              <Printer className="w-3.5 h-3.5 text-white" />
              <span>چاپ و PDF</span>
            </button>

            {/* Offline Computer Run */}
            <button
              onClick={onOpenOfflineExport}
              id="offline-export-btn"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-700 hover:bg-amber-50 dark:hover:bg-slate-600 text-amber-900 dark:text-amber-300 border border-slate-200/80 dark:border-slate-600 hover:border-amber-300 shadow-2xs transition-all cursor-pointer"
              title="اجرای مستقیم در کامپیوتر شخصی و دانلود فایل تکی HTML آفلاین"
            >
              <Laptop className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>آفلاین (HTML)</span>
            </button>
          </div>

          {/* GROUP 3: Utilities, Dark Mode & Architecture */}
          <div className="flex items-center gap-1 p-1 bg-slate-100/80 dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700">
            {/* Dark Mode Toggle */}
            {onToggleDarkMode && (
              <button
                type="button"
                onClick={onToggleDarkMode}
                id="toggle-dark-mode-btn"
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  darkMode
                    ? 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 hover:bg-white dark:hover:bg-slate-700'
                }`}
                title={darkMode ? 'تغییر به تم روشن (روز)' : 'تغییر به تم تاریک (شب)'}
              >
                {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
              </button>
            )}

            {/* AI & JSON Architecture */}
            <button
              onClick={onOpenJsonModal}
              id="ai-json-btn"
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-indigo-700 dark:hover:text-indigo-400 hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
              title="معماری JSON برای اتصال به هوش مصنوعی (Gemini/ChatGPT/Claude) و ویرایش زنده کدها"
            >
              <Code2 className="w-4 h-4" />
            </button>

            {/* Circadian Rhythm Settings */}
            {onOpenCircadian && (
              <button
                onClick={onOpenCircadian}
                id="circadian-btn"
                className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-indigo-700 dark:hover:text-indigo-400 hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
                title="شخصی‌سازی و ویرایش ریتم روان‌شناختی شبانه‌روز (ساعات، رنگ‌ها و تعاریف زیستی)"
              >
                <BrainCircuit className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              </button>
            )}

            {/* Database & Dual-Engine Persistence Settings */}
            {onOpenDatabase && (
              <button
                onClick={onOpenDatabase}
                id="database-settings-btn"
                className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
                title="دیتابیس فوق پایدار ۵ روزه (IndexedDB + LocalStorage) و پشتیبان‌گیری ابری/محلی"
              >
                <Database className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              </button>
            )}

            {/* Smart Rules & Anti-Collision Engine */}
            {onOpenPlannerRules && (
              <button
                onClick={onOpenPlannerRules}
                id="planner-rules-btn"
                className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-indigo-700 dark:hover:text-indigo-400 hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer relative"
                title="موتور منطق و قوانین برنامه‌ریزی: منع تداخل هم‌زمان، سقف کار عمیق و ریتم اولترادین"
              >
                <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full ring-2 ring-white dark:ring-slate-800" />
              </button>
            )}

            {/* Toggle Stats Dashboard */}
            <button
              onClick={onToggleStats}
              id="toggle-stats-btn"
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                showStats
                  ? 'bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 font-bold shadow-2xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-700'
              }`}
              title="نمایش یا پنهان‌سازی داشبورد تعادل هفتگی"
            >
              <BarChart3 className="w-4 h-4" />
            </button>

            {/* Reset to Sample */}
            <button
              onClick={onResetSample}
              id="reset-sample-btn"
              className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
              title="بارگذاری برنامه نمونه پیشنهادی مهندس هوش مصنوعی"
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
            </button>

            {/* Clear Week */}
            <button
              onClick={onClearAll}
              id="clear-all-btn"
              className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
              title="پاک‌سازی هفته با محافظت ۲مرحله‌ای"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json,application/json"
            className="hidden"
            id="json-file-input"
          />
        </div>
      </div>
    </header>
  );
};

