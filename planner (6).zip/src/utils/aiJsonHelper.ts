import { TimeBlock, BlockTemplate, DayKey, CategoryKey, TimePhaseInfo, WeeklyTaskItem } from '../types';
import {
  DAYS,
  CATEGORIES,
  TIME_PHASES as DEFAULT_TIME_PHASES,
  getTimePhase,
  minutesToTimeString,
  formatDurationFa,
  START_HOUR,
  END_HOUR,
  SLOT_INTERVAL,
} from '../constants/plannerConfig';

export interface AiPlannerExport {
  _schema: string;
  generated_at: string;
  app_version: string;
  philosophy_and_methodology: {
    core_framework: string;
    anti_fragility_principles: string[];
    circadian_energy_model: string;
  };
  planner_profile: {
    title: string;
    week_focus_sprint: string;
    operating_hours: string;
    time_slot_interval: string;
  };
  circadian_energy_phases: {
    phase_id: string;
    name_fa: string;
    name_en: string;
    start_hour: number;
    end_hour: number;
    time_window: string;
    description: string;
    color: string;
    recommended_cognitive_load: string;
  }[];
  weekly_notes_and_action_checklist?: {
    order_number: number;
    title: string;
    completed: boolean;
    priority: string;
    category?: string;
    detail_note?: string;
  }[];
  categories_taxonomy: Record<
    CategoryKey,
    {
      label_fa: string;
      tagline_fa: string;
      cognitive_weight: 'very_high' | 'high' | 'medium' | 'restorative';
      role_description: string;
    }
  >;
  weekly_analytics: {
    total_planned_hours: number;
    total_blocks_count: number;
    completed_blocks_count: number;
    completion_rate_percent: number;
    deep_work_hours: number;
    recovery_and_rest_hours: number;
    work_to_recovery_ratio: string;
    day_by_day_breakdown: Record<
      DayKey,
      {
        day_fa: string;
        day_en: string;
        total_hours: number;
        deep_work_hours: number;
        recovery_hours: number;
        blocks_count: number;
        completed_count: number;
      }
    >;
  };
  weekly_schedule_by_day: Record<
    DayKey,
    {
      day_id: DayKey;
      day_name_fa: string;
      day_name_en: string;
      psychological_mood: string;
      total_hours: number;
      blocks_count: number;
      chronological_blocks: {
        id: string;
        time_slot: string;
        start_time_24h: string;
        end_time_24h: string;
        start_minutes: number;
        duration_minutes: number;
        duration_formatted_fa: string;
        title: string;
        subtitle: string;
        category: CategoryKey;
        category_label_fa: string;
        circadian_phase_fa: string;
        status: 'completed' | 'pending';
        notes: string;
      }[];
      free_buffer_slots: {
        time_slot: string;
        duration_minutes: number;
        phase_fa: string;
      }[];
    }
  >;
  templates_bank: {
    id: string;
    title: string;
    subtitle: string;
    category: CategoryKey;
    category_label_fa: string;
    default_duration_minutes: number;
    description: string;
  }[];
  raw_blocks: TimeBlock[];
  raw_time_phases?: TimePhaseInfo[];
  raw_weekly_notes?: WeeklyTaskItem[];
  raw_templates?: BlockTemplate[];
  weekly_pillars_goals?: Record<string, any>;
  planner_rules_config?: Record<string, any>;
  ai_assistant_prompts: {
    master_ai_system_prompt: string;
    system_instruction: string;
    prompt_for_full_schedule_update: string;
    prompt_for_schedule_audit: string;
    prompt_for_daily_briefing: string;
    prompt_for_late_shift_rebalance: string;
  };
}

/**
 * Builds an AI-optimized and human-readable comprehensive JSON structure.
 * Contains both high-level semantic summaries for LLMs (Gemini, ChatGPT, Claude)
 * and raw structured blocks for lossless re-import.
 */
export function buildAiPlannerJson(
  title: string,
  weekRange: string,
  blocks: TimeBlock[],
  templates: BlockTemplate[],
  timePhases?: TimePhaseInfo[],
  weeklyNotes?: WeeklyTaskItem[],
  weeklyGoals?: any,
  plannerRules?: any
): AiPlannerExport {
  const activePhases = timePhases && timePhases.length > 0 ? timePhases : DEFAULT_TIME_PHASES;
  const activeNotes = weeklyNotes || [];

  const resolvePhase = (hour: number) => {
    const found = activePhases.find((p) => hour >= p.startHour && hour < p.endHour);
    if (found) return found;
    return activePhases[0] || DEFAULT_TIME_PHASES[0];
  };

  // Sort blocks chronologically
  const sortedBlocks = [...blocks].sort((a, b) => a.startMinutes - b.startMinutes);

  // Compute analytics
  let totalMinutes = 0;
  let deepWorkMinutes = 0;
  let recoveryMinutes = 0;
  let completedCount = 0;

  const dayStats: Record<
    DayKey,
    {
      totalMinutes: number;
      deepWorkMinutes: number;
      recoveryMinutes: number;
      blocksCount: number;
      completedCount: number;
    }
  > = {
    sat: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
    sun: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
    mon: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
    tue: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
    wed: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
    thu: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
    fri: { totalMinutes: 0, deepWorkMinutes: 0, recoveryMinutes: 0, blocksCount: 0, completedCount: 0 },
  };

  sortedBlocks.forEach((b) => {
    totalMinutes += b.durationMinutes;
    if (b.completed) completedCount++;

    const isDeep = b.category === 'pytorch' || b.category === 'python' || b.category === 'work';
    const isRecovery = b.category === 'recovery' || b.category === 'gaming';

    if (isDeep) deepWorkMinutes += b.durationMinutes;
    if (isRecovery) recoveryMinutes += b.durationMinutes;

    if (dayStats[b.day]) {
      dayStats[b.day].totalMinutes += b.durationMinutes;
      dayStats[b.day].blocksCount++;
      if (b.completed) dayStats[b.day].completedCount++;
      if (isDeep) dayStats[b.day].deepWorkMinutes += b.durationMinutes;
      if (isRecovery) dayStats[b.day].recoveryMinutes += b.durationMinutes;
    }
  });

  const completionRate =
    sortedBlocks.length > 0 ? Math.round((completedCount / sortedBlocks.length) * 100) : 0;
  const ratio =
    recoveryMinutes > 0
      ? `${(deepWorkMinutes / recoveryMinutes).toFixed(1)} : 1 (کار عمیق به ریکاوری)`
      : 'بدون ریکاوری ثبت‌شده';

  // Build daily schedule by day
  const weeklyScheduleByDay = {} as AiPlannerExport['weekly_schedule_by_day'];
  const dayBreakdown = {} as AiPlannerExport['weekly_analytics']['day_by_day_breakdown'];

  DAYS.forEach((dayInfo) => {
    const dayBlocks = sortedBlocks.filter((b) => b.day === dayInfo.id);
    const dayTotalMin = dayStats[dayInfo.id].totalMinutes;

    dayBreakdown[dayInfo.id] = {
      day_fa: dayInfo.nameFa,
      day_en: dayInfo.nameEn,
      total_hours: +(dayTotalMin / 60).toFixed(1),
      deep_work_hours: +(dayStats[dayInfo.id].deepWorkMinutes / 60).toFixed(1),
      recovery_hours: +(dayStats[dayInfo.id].recoveryMinutes / 60).toFixed(1),
      blocks_count: dayStats[dayInfo.id].blocksCount,
      completed_count: dayStats[dayInfo.id].completedCount,
    };

    // Formatted blocks
    const chronologicalBlocks = dayBlocks.map((b) => {
      const startStr = minutesToTimeString(b.startMinutes);
      const endStr = minutesToTimeString(b.startMinutes + b.durationMinutes);
      const cat = CATEGORIES[b.category] || CATEGORIES.custom;
      const hour = Math.floor(b.startMinutes / 60);
      const phase = getTimePhase(hour);

      return {
        id: b.id,
        time_slot: `${startStr} - ${endStr}`,
        start_time_24h: startStr,
        end_time_24h: endStr,
        start_minutes: b.startMinutes,
        duration_minutes: b.durationMinutes,
        duration_formatted_fa: formatDurationFa(b.durationMinutes),
        title: b.title,
        subtitle: b.subtitle || '',
        category: b.category,
        category_label_fa: cat.label,
        circadian_phase_fa: phase.nameFa,
        status: (b.completed ? 'completed' : 'pending') as 'completed' | 'pending',
        notes: b.note || '',
      };
    });

    // Detect free buffer intervals (30+ min gaps)
    const freeBuffers: { time_slot: string; duration_minutes: number; phase_fa: string }[] = [];
    let currentMarker = START_HOUR * 60;
    dayBlocks.forEach((b) => {
      if (b.startMinutes > currentMarker) {
        const gap = b.startMinutes - currentMarker;
        if (gap >= 30) {
          const phase = getTimePhase(Math.floor(currentMarker / 60));
          freeBuffers.push({
            time_slot: `${minutesToTimeString(currentMarker)} - ${minutesToTimeString(b.startMinutes)}`,
            duration_minutes: gap,
            phase_fa: phase.nameFa,
          });
        }
      }
      currentMarker = Math.max(currentMarker, b.startMinutes + b.durationMinutes);
    });
    if (currentMarker < END_HOUR * 60) {
      const gap = END_HOUR * 60 - currentMarker;
      if (gap >= 30) {
        const phase = getTimePhase(Math.floor(currentMarker / 60));
        freeBuffers.push({
          time_slot: `${minutesToTimeString(currentMarker)} - ${minutesToTimeString(END_HOUR * 60)}`,
          duration_minutes: gap,
          phase_fa: phase.nameFa,
        });
      }
    }

    weeklyScheduleByDay[dayInfo.id] = {
      day_id: dayInfo.id,
      day_name_fa: dayInfo.nameFa,
      day_name_en: dayInfo.nameEn,
      psychological_mood: dayInfo.mood,
      total_hours: +(dayTotalMin / 60).toFixed(1),
      blocks_count: dayBlocks.length,
      chronological_blocks: chronologicalBlocks,
      free_buffer_slots: freeBuffers,
    };
  });

  return {
    _schema: 'anti-fragile-timebox-ai-v2',
    generated_at: new Date().toISOString(),
    app_version: '2.0.0',
    philosophy_and_methodology: {
      core_framework: 'Anti-Fragile Timeboxing & Circadian Biological Rhythm Alignment',
      anti_fragility_principles: [
        '۱ همیشه از ۰ بزرگ‌تر است: در صورت بروز تاخیر، کل روز را رها نکنید؛ بلوک‌ها را شیفت دهید.',
        'آشتی با بیداری دیرهنگام (Late Shift Grace): انتقال نرم کارها بدون احساس گناه.',
        'تطابق شناختی با فازهای انرژی شبانه‌روز: اختصاص ساعات طلایی (۰۹:۰۰ تا ۱۳:۰۰) به کارهای عمیق مغزی.',
        'ریکاوری محافظت‌شده (Protected Recovery): ایجاد فضاهای تنفس و بازیابی انرژی به عنوان وظیفه حرفه‌ای.',
      ],
      circadian_energy_model:
        'تقسیم شبانه‌روز به ۵ فاز روان‌شناختی جهت تنظیم بهینه بار شناختی با نوسانات دوپامین و کورتیزول.',
    },
    planner_profile: {
      title,
      week_focus_sprint: weekRange,
      operating_hours: `${minutesToTimeString(START_HOUR * 60)} to ${minutesToTimeString(END_HOUR * 60)}`,
      time_slot_interval: `${SLOT_INTERVAL} minutes`,
    },
    circadian_energy_phases: activePhases.map((p) => ({
      phase_id: p.id,
      name_fa: p.nameFa,
      name_en: p.nameEn,
      start_hour: p.startHour,
      end_hour: p.endHour,
      time_window: `${String(p.startHour).padStart(2, '0')}:00 - ${String(p.endHour).padStart(2, '0')}:00`,
      description: p.description,
      color: p.color,
      recommended_cognitive_load:
        p.id === 'deep_focus'
          ? 'Maximum cognitive load (AI models, Deep Math, Systems Architecture)'
          : p.id === 'morning'
          ? 'Moderate, warming up (Routines, light physical exercise, sprint review)'
          : p.id === 'afternoon_momentum'
          ? 'Medium execution (Meetings, university lectures, PR reviews)'
          : p.id === 'twilight_synthesis'
          ? 'Creative & broad learning (Arxiv reading, open-source exploratory)'
          : 'Zero work, mental wind-down & nervous system recovery',
    })),
    weekly_notes_and_action_checklist: activeNotes.map((n) => ({
      order_number: n.order,
      title: n.text,
      completed: n.completed,
      priority: n.priority,
      category: n.category,
      detail_note: n.note,
    })),
    categories_taxonomy: {
      pytorch: {
        label_fa: CATEGORIES.pytorch.label,
        tagline_fa: CATEGORIES.pytorch.tagline,
        cognitive_weight: 'very_high',
        role_description: 'توسعه مدل‌های هوش مصنوعی، یادگیری عمیق، پردازش تنسورها و آموزش شبکه‌ها',
      },
      python: {
        label_fa: CATEGORIES.python.label,
        tagline_fa: CATEGORIES.python.tagline,
        cognitive_weight: 'high',
        role_description: 'کدنویسی عمیق پایتون، معماری نرم‌افزار، الگوریتم‌ها و تست',
      },
      work: {
        label_fa: CATEGORIES.work.label,
        tagline_fa: CATEGORIES.work.tagline,
        cognitive_weight: 'high',
        role_description: 'پروژه‌های کاری، لینوکس، تعاملات گیت و توسعه سیستمی',
      },
      university: {
        label_fa: CATEGORIES.university.label,
        tagline_fa: CATEGORIES.university.tagline,
        cognitive_weight: 'medium',
        role_description: 'حضور در دانشگاه، کلاس‌های نظری و عملی، رفت‌وآمد',
      },
      meeting: {
        label_fa: CATEGORIES.meeting.label,
        tagline_fa: CATEGORIES.meeting.tagline,
        cognitive_weight: 'medium',
        role_description: 'جلسات هماهنگی، بازبینی اسپرینت و ارتباطات گروهی',
      },
      habit: {
        label_fa: CATEGORIES.habit.label,
        tagline_fa: CATEGORIES.habit.tagline,
        cognitive_weight: 'medium',
        role_description: 'عادت‌های پیوسته مانند تقویت زبان انگلیسی و مطالعه خرد',
      },
      recovery: {
        label_fa: CATEGORIES.recovery.label,
        tagline_fa: CATEGORIES.recovery.tagline,
        cognitive_weight: 'restorative',
        role_description: 'تغذیه مناسب، تنفس آگاهانه، چای و استراحت مغزی',
      },
      gaming: {
        label_fa: CATEGORIES.gaming.label,
        tagline_fa: CATEGORIES.gaming.tagline,
        cognitive_weight: 'restorative',
        role_description: 'تخلیه هیجان و تفریح کنترل‌شده برای بازگشت دوپامین',
      },
      custom: {
        label_fa: CATEGORIES.custom.label,
        tagline_fa: CATEGORIES.custom.tagline,
        cognitive_weight: 'medium',
        role_description: 'فعالیت‌های آزاد و امور شخصی متفرقه',
      },
    },
    weekly_analytics: {
      total_planned_hours: +(totalMinutes / 60).toFixed(1),
      total_blocks_count: sortedBlocks.length,
      completed_blocks_count: completedCount,
      completion_rate_percent: completionRate,
      deep_work_hours: +(deepWorkMinutes / 60).toFixed(1),
      recovery_and_rest_hours: +(recoveryMinutes / 60).toFixed(1),
      work_to_recovery_ratio: ratio,
      day_by_day_breakdown: dayBreakdown,
    },
    weekly_schedule_by_day: weeklyScheduleByDay,
    templates_bank: templates.map((t) => ({
      id: t.id,
      title: t.title,
      subtitle: t.subtitle,
      category: t.category,
      category_label_fa: CATEGORIES[t.category]?.label || 'سفارشی',
      default_duration_minutes: t.defaultDuration,
      description: t.description,
    })),
    raw_blocks: blocks,
    raw_time_phases: activePhases,
    raw_weekly_notes: activeNotes,
    raw_templates: templates,
    weekly_pillars_goals: weeklyGoals || undefined,
    planner_rules_config: plannerRules || undefined,
    ai_assistant_prompts: {
      master_ai_system_prompt: `### MASTER AI SYSTEM INSTRUCTION: ANTI-FRAGILE TIMEBOXING ARCHITECT & PLANNER ENGINE
You are an expert Anti-Fragile Timeboxing & Cognitive Ergonomics AI assistant for software and AI engineers.
You have been provided with the COMPLETE live state of the user's weekly planner in JSON format.

#### 1. CORE ARCHITECTURAL RULES & SCHEMA:
- **Operating Days**: "sat" (Saturday), "sun" (Sunday), "mon" (Monday), "tue" (Tuesday), "wed" (Wednesday), "thu" (Thursday), "fri" (Friday).
- **Time Boundary**: 07:00 (420 minutes) to 24:00 (1440 minutes). No block can start before 420 or extend past 1440.
- **Allowed Categories**:
  * "pytorch" (Deep Work / High Cognitive Load / Model training, architecture)
  * "python" (Deep Work / High Cognitive Load / Advanced algorithms, backend)
  * "work" (Career / High Cognitive Load / System engineering, Git, Linux, freelance)
  * "university" (Academic / High Cognitive Load / Courses, homework, projects)
  * "meeting" (Coordination / Medium Cognitive Load / Standups, group reviews)
  * "habit" (Micro-habits / Medium Load / Reading, English vocabulary, practice)
  * "recovery" (Restorative / Zero Pressure / Mindful breath, nutritious meal, walk)
  * "gaming" (Restorative / Dopamine recharge / Controlled gaming, hobby, fun)
  * "custom" (Personal & miscellaneous)
- **TimeBlock Model**:
  \`\`\`typescript
  {
    "id": string, // Unique ID (e.g., "block-sat-0900-deepwork")
    "title": string, // Clear task title in Persian or English
    "category": CategoryKey, // One of the allowed categories above
    "day": "sat" | "sun" | "mon" | "tue" | "wed" | "thu" | "fri",
    "startMinutes": number, // Minutes from midnight (e.g., 09:00 = 540, 14:30 = 870)
    "durationMinutes": number, // 15, 30, 45, 60, 90, 120, etc.
    "subtitle"?: string, // Brief sub-focus or project tag
    "note"?: string, // Optional focus details / checklist
    "completed"?: boolean // true / false
  }
  \`\`\`
- **Strict Non-Overlap Principle**: Two tasks cannot occupy the exact same time window. If a task starts at 540 for 90 minutes (ends at 630), the next task should start at or after 630.
- **Cognitive Balance**: Deep work should be scheduled during biological peak energy windows (09:00 - 13:00 and 17:00 - 20:00). Restorative buffers ("recovery" / "gaming") must follow intense 90-minute ultradian cycles.

#### 2. INSTRUCTIONS FOR UPDATING & GENERATING THE SCHEDULE:
When the user asks you to:
1. Add, modify, shift, or optimize tasks or entire days
2. Balance deep work against university or job duties
3. Re-structure the schedule following a delay or late wake-up
4. Generate a brand-new weekly plan from their goals

YOU MUST ALWAYS:
1. Provide your clear, empathetic, and strategic reasoning in Persian.
2. Provide a single, complete, valid JSON code block that the user can copy and paste directly into the app's "ویرایشگر زنده JSON" (Live JSON Editor) to apply immediately with 1 click.
3. The JSON code block should format as:
\`\`\`json
{
  "title": "${title}",
  "weekRange": "${weekRange}",
  "blocks": [
    // Array of all TimeBlock objects for the week, properly timed and non-overlapping
  ],
  "templates": [
    // Array of BlockTemplate objects for the template bank
  ],
  "weeklyNotes": [
    // Array of strategic priorities/notes
  ]
}
\`\`\`
This allows seamless two-way synchronization between your AI recommendations and the interactive planner UI!`,
      system_instruction:
        'You are an elite, compassionate Deep Work and Anti-Fragile Timeboxing productivity coach specialized in AI & Software Engineers. You understand circadian energy phases, work-to-recovery ratios, and the anti-fragile principle that "1 is always greater than 0".',
      prompt_for_full_schedule_update: `### 🎯 پرامپت مهندسی‌شده و جامع برای بازطراحی کامل برنامه، بانک الگوها و اهداف (JSON Master Architecture Prompt)

شما یک مربی ارشد و معمار برجسته سیستم‌های بهره‌وری ضدشکننده (Anti-Fragile Timeboxing & Deep Work Architect) هستید که تخصص شما در ریتم‌های شبانه‌روزی (Circadian Rhythm)، چرخه‌های ۹۰ دقیقه‌ای اولترادیان (Ultradian Cycles)، و زمان‌بندی مهندسی نرم‌افزار و هوش مصنوعی است.

بر اساس ساختار داده‌ای JSON پیوست‌شده در این پیام و اهداف/تغییرات جدید من، وظیفه شما این است که:
۱. ساختار کل هفته را بازبینی و بهینه‌سازی کنید.
۲. بانک الگوها (Templates Bank) را با کارت‌های تکرارپذیر، هوشمند و استانداردی متناسب با دسته‌بندی‌های کلیدی (PyTorch، Python، کار عمیق، درس، میتینگ، عادات و ریکاوری) کاملاً غنی و به‌روز کنید.
۳. اولویت‌های استراتژیک هفتگی (Weekly Notes & Brain Dump) را تنظیم نمایید.
۴. تمامی بلوک‌های زمانی را بدون حتی ۱ دقیقه تداخل در روزهای شنبه تا جمعه (sat تا fri) بچینید.

---

#### ⚖️ قوانین حیاتی و بدون استثنای سیستم (Non-Negotiable Constraints):
۱. **اصل صفر-تداخل (Zero Overlap):** هیچ دو کارتی در یک روز نباید حتی ۱ دقیقه اشتراک زمانی داشته باشند. اگر تسک اول در دقیقه ۵۴۰ (ساعت ۰۹:۰۰) شروع و ۹۰ دقیقه طول می‌کشد، پایان آن دقیقه ۶۳۰ است و تسک بعدی باید حداقل در دقیقه ۶۳۰ یا با یک بافر ۵ تا ۱۵ دقیقه‌ای شروع شود.
۲. **محدوده مجاز ساعت کاری روزانه:** صرفاً بین ساعت 07:00 (دقیقه ۴۲۰) تا ساعت 24:00 (دقیقه ۱۴۴۰).
۳. **ترازبندی بیولوژیکی انرژی (Circadian Alignment):**
   - فاز ۱ (۰۷:۰۰ تا ۰۹:۰۰): شروع آرام، ورزش، مرور روز (Launch & Routine)
   - فاز ۲ (۰۹:۰۰ تا ۱۳:۰۰): سنگین‌ترین کار عمیق (Deep Work 1 - PyTorch, Core Architecture, Python)
   - فاز ۳ (۱۳:۰۰ تا ۱۵:۰۰): ناهار، استراحت، کارهای سبک، جلسات هماهنگی (Restoration & Low Load)
   - فاز ۴ (۱۵:۰۰ تا ۱۷:۰۰): کارهای اجرایی، مطالعه، جلسات، دانشگاه (Executive & Projects)
   - فاز ۵ (۱۷:۰۰ تا ۲۰:۰۰): کار عمیق دوم، پروژه‌های شخصی و تمرین (Deep Work 2)
   - فاز ۶ (۲۰:۰۰ تا ۲۲:۰۰): ورزش سبک، تفریح، مطالعه یا گیمینگ کنترل‌شده (Recovery & Joy)
   - فاز ۷ (۲۲:۰۰ تا ۲۴:۰۰): مرور روز، آماده‌سازی خواب، خاموشی کامل (Wind-down & Sleep Prep)
۴. **توازن کار به ریکاوری:** پس از هر جلسه عمیق ۹۰ یا ۱۲۰ دقیقه‌ای، یک بلاک ریکاوری ۱۵ تا ۳۰ دقیقه‌ای قرار دهید تا از خستگی ادراکی مغز جلوگیری شود.
۵. **دسته‌بندی‌های مجاز (Category Taxonomy):**
   - \`pytorch\`: یادگیری عمیق، مدل‌سازی، کدنویسی تخصصی هوش مصنوعی
   - \`python\`: توسعه پایتون، الگوریتم‌ها، پروژه‌های بک‌اند و داده
   - \`work\`: پروژه‌های کاری، تعهدات شغلی، معماری سیستم
   - \`university\`: درس، دانشگاه، تکالیف، مقاله‌خوانی
   - \`meeting\`: جلسات هماهنگی، استندآپ، منتورینگ
   - \`habit\`: عادات خرد (زبان انگلیسی، کتابخوانی، ذهن‌آگاهی)
   - \`recovery\`: ناهار، پیاده‌روی، استراحت ذهنی، مدیتیشن
   - \`gaming\`: تفریح، بازی کنترل‌شده، سرگرمی
   - \`custom\`: امور شخصی و متفرقه

---

#### 📦 قالب استاندارد خروجی (فقط یک بلوک کد معتبر JSON):
لطفاً پاسخ نهایی خود را به زبان فارسی با یک تحلیل کوتاه و سپس دقیقاً در قالب بلوک کد JSON زیر ارائه دهید تا من بتوانم با یک کلیک آن را در تب «ویرایشگر زنده JSON» این برنامه کپی و بلافاصله اعمال کنم:

\`\`\`json
{
  "title": "${title}",
  "weekRange": "${weekRange}",
  "blocks": [
    {
      "id": "block-sat-0730-routine",
      "day": "sat",
      "title": "ورزش صبحگاهی و برنامه‌ریزی روز",
      "subtitle": "فاز راه‌اندازی روزانه",
      "category": "habit",
      "startMinutes": 450,
      "durationMinutes": 60,
      "note": "کشش، نوشیدن آب کافی و تعیین ۳ سنگ بزرگ روز",
      "completed": false
    },
    {
      "id": "block-sat-0900-pytorch",
      "day": "sat",
      "title": "پیاده‌سازی ماژول Attention و ترنسفورمر",
      "subtitle": "پروژه عمیق یادگیری هوش مصنوعی",
      "category": "pytorch",
      "startMinutes": 540,
      "durationMinutes": 90,
      "note": "تمرکز خالص بدون موبایل و نوتیفیکیشن",
      "completed": false
    }
  ],
  "templates": [
    {
      "id": "tmpl-pytorch-sprint",
      "title": "اسپرینت کدنویسی PyTorch",
      "subtitle": "کار عمیق ۹۰ دقیقه‌ای یادگیری ماشین",
      "category": "pytorch",
      "defaultDuration": 90,
      "description": "حل معماری شبکه‌ها و بهینه‌سازی گرادیان"
    },
    {
      "id": "tmpl-python-algo",
      "title": "توسعه و ریفکتور پایتون",
      "subtitle": "اسپرینت ساختاری کد",
      "category": "python",
      "defaultDuration": 60,
      "description": "نوشتن Unit Testها و بهینه‌سازی عملکرد"
    },
    {
      "id": "tmpl-recovery-walk",
      "title": "ریکاوری فعال و پیاده‌روی",
      "subtitle": "تخلیه بار شناختی ذهن",
      "category": "recovery",
      "defaultDuration": 30,
      "description": "هوای آزاد و استراحت کامل چشمی"
    }
  ],
  "weeklyNotes": [
    {
      "id": "note-1",
      "text": "تکمیل و دپلوی ماژول اصلی یادگیری عمیق",
      "completed": false,
      "priority": "high"
    },
    {
      "id": "note-2",
      "text": "حداقل ۱۲ ساعت کار عمیق خالص در طول هفته",
      "completed": false,
      "priority": "high"
    },
    {
      "id": "note-3",
      "text": "حفظ خواب منظم شبانه (خواب قبل از ۰۰:۳۰)",
      "completed": false,
      "priority": "medium"
    }
  ]
}
\`\`\`

اکنون لطفاً بر اساس نیازمندی‌های من و داده‌های فعلی بالا، برنامه کامل هفته، بانک الگوها و یادداشت‌های استراتژیک را با بالاترین دقت مهندسی بازتولید و تولید کنید:`,
      prompt_for_schedule_audit: `Analyze my weekly schedule above. Review:
1. Cognitive Load Distribution: Is my heavy Deep Work (PyTorch, Python, Work) aligned with peak biological focus hours (09:00 - 13:00)?
2. Recovery Balance: Do I have enough protected buffer and restorative blocks between deep sessions to avoid burnout?
3. Fragility Vulnerability: Identify any days with back-to-back dense commitments that are at risk of collapsing if delayed.
4. Three concrete, anti-fragile recommendations to optimize my week.`,
      prompt_for_daily_briefing: `Generate an executive, encouraging daily briefing for today based on the schedule provided. Summarize what needs to be accomplished in each energy phase, highlight the single most impactful high-leverage task, and provide one anti-fragile mindset reminder.`,
      prompt_for_late_shift_rebalance: `I woke up 2 hours later than planned today. Based on the anti-fragile schedule for today, re-prioritize and compress my blocks without guilt so that I still complete high-value deep work while preserving necessary rest.`,
    },
  };
}
