import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  TimeBlock,
  BlockTemplate,
  DayKey,
  PlannerData,
  TimePhaseInfo,
  WeeklyTaskItem,
  PlannerRulesConfig,
  WeeklyPillarsGoals,
  CategoryKey,
} from './types';
import {
  INITIAL_TEMPLATES,
  INITIAL_SAMPLE_BLOCKS,
  START_HOUR,
  END_HOUR,
  SLOT_INTERVAL,
  TIME_PHASES,
  DAYS,
  toFaDigits,
} from './constants/plannerConfig';
import { DEFAULT_PLANNER_RULES, DEFAULT_WEEKLY_GOALS } from './constants/defaultPlannerRules';
import {
  cascadeInsertBlock,
  cascadeMoveBlock,
  resolveDayCollisions,
  hasOverlapInDay,
} from './utils/timeCollisionEngine';
import { Header } from './components/Header';
import { SidebarBank } from './components/SidebarBank';
import { TimeGrid } from './components/TimeGrid';
import { BlockModal } from './components/BlockModal';
import { LateShiftModal } from './components/LateShiftModal';
import { WeekStats } from './components/WeekStats';
import { TemplateModal } from './components/TemplateModal';
import { PrintModal } from './components/PrintModal';
import { JsonModal } from './components/JsonModal';
import { DailyReportModal } from './components/DailyReportModal';
import { ClearConfirmModal } from './components/ClearConfirmModal';
import { OfflineExportModal } from './components/OfflineExportModal';
import { SpecialWeeklyReportModal } from './components/SpecialWeeklyReportModal';
import { InsertBreakModal } from './components/InsertBreakModal';
import { CircadianModal } from './components/CircadianModal';
import { DatabaseSettingsModal } from './components/DatabaseSettingsModal';
import { WeeklyNotesSection } from './components/WeeklyNotesSection';
import { PlannerRulesModal } from './components/PlannerRulesModal';
import { WeekGoalsModal } from './components/WeekGoalsModal';
import { AutoSleepMovieModal } from './components/AutoSleepMovieModal';
import {
  injectSleepAndMovieBlocks,
  isSleepOrMovieBlock,
  AutoSleepMovieConfig,
} from './utils/autoSleepMovieEngine';
import { PlannerStorageService, INITIAL_WEEKLY_NOTES } from './services/plannerStorage';
import { CheckCircle2, AlertCircle, Info, Sparkles } from 'lucide-react';

export default function App() {
  // Synchronous Dual-Engine Pre-Load (0ms latency, 100% resilient across refreshes and 5-day uptime)
  const initialStorageData = useMemo(() => PlannerStorageService.loadSync(), []);

  // State
  const [plannerTitle, setPlannerTitle] = useState<string>(
    initialStorageData?.title || 'برنامه‌ریز هفتگی تایم‌باکسینگ (Anti-Fragile)'
  );
  const [weekRange, setWeekRange] = useState<string>(
    initialStorageData?.weekRange || 'اسپرینت لینوکس و مدل‌سازی یادگیری عمیق'
  );
  const [templates, setTemplates] = useState<BlockTemplate[]>(
    initialStorageData?.templates && initialStorageData.templates.length > 0
      ? initialStorageData.templates
      : INITIAL_TEMPLATES
  );
  const [blocks, setBlocks] = useState<TimeBlock[]>(
    initialStorageData?.blocks && initialStorageData.blocks.length > 0
      ? initialStorageData.blocks
      : INITIAL_SAMPLE_BLOCKS
  );
  const [timePhases, setTimePhases] = useState<TimePhaseInfo[]>(
    initialStorageData?.timePhases && initialStorageData.timePhases.length > 0
      ? initialStorageData.timePhases
      : TIME_PHASES
  );
  const [weeklyNotes, setWeeklyNotes] = useState<WeeklyTaskItem[]>(
    initialStorageData?.weeklyNotes && initialStorageData.weeklyNotes.length > 0
      ? initialStorageData.weeklyNotes
      : INITIAL_WEEKLY_NOTES
  );
  const [customCategoryColors, setCustomCategoryColors] = useState<Record<string, string>>(
    initialStorageData?.customCategoryColors || {}
  );
  const [plannerRules, setPlannerRules] = useState<PlannerRulesConfig>(
    initialStorageData?.plannerRules || DEFAULT_PLANNER_RULES
  );
  const [weeklyGoals, setWeeklyGoals] = useState<WeeklyPillarsGoals>(
    initialStorageData?.weeklyGoals || DEFAULT_WEEKLY_GOALS
  );

  // Modals & Drawers
  const [selectedBlock, setSelectedBlock] = useState<TimeBlock | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<BlockTemplate | null>(null);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isLateShiftOpen, setIsLateShiftOpen] = useState(false);
  const [isSleepMovieModalOpen, setIsSleepMovieModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isJsonModalOpen, setIsJsonModalOpen] = useState(false);
  const [isDailyReportOpen, setIsDailyReportOpen] = useState(false);
  const [isSpecialReportOpen, setIsSpecialReportOpen] = useState(false);
  const [isInsertBreakOpen, setIsInsertBreakOpen] = useState(false);
  const [breakTargetBlock, setBreakTargetBlock] = useState<TimeBlock | null>(null);
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isOfflineModalOpen, setIsOfflineModalOpen] = useState(false);
  const [isCircadianModalOpen, setIsCircadianModalOpen] = useState(false);
  const [isDatabaseModalOpen, setIsDatabaseModalOpen] = useState(false);
  const [isPlannerRulesOpen, setIsPlannerRulesOpen] = useState(false);
  const [isWeekGoalsOpen, setIsWeekGoalsOpen] = useState(false);
  const [showStats, setShowStats] = useState(true);
  const [isFullscreenGrid, setIsFullscreenGrid] = useState(false);

  // Dark mode state with persistence and system preference sync
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('app_dark_mode');
      if (saved !== null) return saved === 'true';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('app_dark_mode', 'true');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('app_dark_mode', 'false');
      }
    } catch (e) {
      console.warn('Dark mode sync error:', e);
    }
  }, [isDarkMode]);

  // Unified clipboard system for 1-click copy & paste
  const [clipboardItem, setClipboardItem] = useState<{
    type: 'block' | 'template';
    title: string;
    subtitle?: string;
    category: CategoryKey;
    durationMinutes: number;
    note?: string;
  } | null>(null);

  // Toast notification
  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'info' | 'warn';
  } | null>(null);

  const showToast = useCallback(
    (message: string, type: 'success' | 'info' | 'warn' = 'success') => {
      setToast({ message, type });
      setTimeout(() => {
        setToast((current) => (current?.message === message ? null : current));
      }, 3500);
    },
    []
  );

  // Asynchronous verification from IndexedDB on startup
  useEffect(() => {
    PlannerStorageService.loadAsync()
      .then((asyncData) => {
        if (asyncData) {
          if (asyncData.title) setPlannerTitle(asyncData.title);
          if (asyncData.weekRange) setWeekRange(asyncData.weekRange);
          if (asyncData.templates && asyncData.templates.length > 0) setTemplates(asyncData.templates);
          if (asyncData.blocks && asyncData.blocks.length > 0) setBlocks(asyncData.blocks);
          if (asyncData.timePhases && asyncData.timePhases.length > 0) setTimePhases(asyncData.timePhases);
          if (asyncData.weeklyNotes) setWeeklyNotes(asyncData.weeklyNotes);
          if (asyncData.customCategoryColors) setCustomCategoryColors(asyncData.customCategoryColors);
          if (asyncData.plannerRules) setPlannerRules(asyncData.plannerRules);
          if (asyncData.weeklyGoals) setWeeklyGoals(asyncData.weeklyGoals);
        }
      })
      .catch((e) => console.warn('Dual-engine async load check completed', e));
  }, []);

  // Check if any overlaps currently exist across the entire week
  const hasAnyOverlaps = useMemo(() => {
    return DAYS.some((d) => hasOverlapInDay(blocks, d.id));
  }, [blocks]);

  // Dual-Engine Persistent Storage (Debounced writes to IndexedDB + LocalStorage)
  useEffect(() => {
    const dataToSave: PlannerData = {
      version: '3.0.0',
      title: plannerTitle,
      weekRange,
      updatedAt: new Date().toISOString(),
      blocks,
      templates,
      timePhases,
      weeklyNotes,
      customCategoryColors,
      plannerRules,
      weeklyGoals,
    };
    PlannerStorageService.save(dataToSave);
  }, [
    plannerTitle,
    weekRange,
    blocks,
    templates,
    timePhases,
    weeklyNotes,
    customCategoryColors,
    plannerRules,
    weeklyGoals,
  ]);

  // High-Precision Multi-Step Undo / Redo Engine (Ctrl+Z / Ctrl+Y)
  interface HistoryStep {
    blocks: TimeBlock[];
    action: string;
  }
  const [undoStack, setUndoStack] = useState<HistoryStep[]>([]);
  const [redoStack, setRedoStack] = useState<HistoryStep[]>([]);

  // History updater wrapper ensuring complete mathematical snapshotting
  const setBlocksWithHistory = useCallback(
    (
      newBlocksOrUpdater: TimeBlock[] | ((prev: TimeBlock[]) => TimeBlock[]),
      actionName: string = 'تغییر برنامه'
    ) => {
      setBlocks((currentBlocks) => {
        const nextBlocks =
          typeof newBlocksOrUpdater === 'function'
            ? newBlocksOrUpdater(currentBlocks)
            : newBlocksOrUpdater;

        if (nextBlocks === currentBlocks) return currentBlocks;

        setUndoStack((prev) => {
          const step: HistoryStep = {
            blocks: currentBlocks,
            action: actionName,
          };
          return [...prev, step].slice(-50); // up to 50 steps
        });
        setRedoStack([]); // reset redo on any fresh user action
        return nextBlocks;
      });
    },
    []
  );

  // Undo (Ctrl+Z)
  const handleUndo = useCallback(() => {
    setUndoStack((prevUndo) => {
      if (prevUndo.length === 0) {
        showToast('موردی برای بازگشت (Undo) در تاریخچه وجود ندارد.', 'info');
        return prevUndo;
      }
      const lastStep = prevUndo[prevUndo.length - 1];
      const nextUndo = prevUndo.slice(0, -1);

      setBlocks((currentBlocks) => {
        setRedoStack((prevRedo) => [
          ...prevRedo,
          { blocks: currentBlocks, action: lastStep.action },
        ].slice(-50));
        return lastStep.blocks;
      });

      showToast(`بازگشت به عقب: ${lastStep.action} (Ctrl + Z)`, 'info');
      return nextUndo;
    });
  }, [showToast]);

  // Redo (Ctrl+Y)
  const handleRedo = useCallback(() => {
    setRedoStack((prevRedo) => {
      if (prevRedo.length === 0) {
        showToast('موردی برای انجام مجدد (Redo) در تاریخچه وجود ندارد.', 'info');
        return prevRedo;
      }
      const nextStep = prevRedo[prevRedo.length - 1];
      const nextRedo = prevRedo.slice(0, -1);

      setBlocks((currentBlocks) => {
        setUndoStack((prevUndo) => [
          ...prevUndo,
          { blocks: currentBlocks, action: nextStep.action },
        ].slice(-50));
        return nextStep.blocks;
      });

      showToast(`انجام مجدد: ${nextStep.action} (Ctrl + Y)`, 'info');
      return nextRedo;
    });
  }, [showToast]);

  // Automatic Sleep & Movie Injector
  const handleApplySleepAndMovie = useCallback(
    (config: AutoSleepMovieConfig) => {
      setBlocksWithHistory((prev) => {
        const { updatedBlocks, summary } = injectSleepAndMovieBlocks(prev, config);
        let msg = `چینش هوشمند انجام شد: ${toFaDigits(summary.sleepBlocksAdded)} خواب شبانه، ${toFaDigits(summary.movieBlocksAdded)} سانس فیلم`;
        if (summary.napBlocksAdded > 0) {
          msg += ` و ${toFaDigits(summary.napBlocksAdded)} چرت نیمروزی`;
        }
        if (summary.adjustedTasksCount > 0) {
          msg += ` (${toFaDigits(summary.adjustedTasksCount)} تسک هماهنگ شدند)`;
        }
        showToast(msg, 'success');
        return updatedBlocks;
      }, 'چینش خودکار خواب و فیلم');
    },
    [setBlocksWithHistory, showToast]
  );

  const handleClearSleepAndMovie = useCallback(() => {
    setBlocksWithHistory((prev) => {
      const updated = prev.filter((b) => !isSleepOrMovieBlock(b));
      showToast('کارت‌های خواب و فیلم از تقویم برداشته شدند.', 'info');
      return updated;
    }, 'حذف کارت‌های خواب و فیلم');
  }, [setBlocksWithHistory, showToast]);

  // Automatic Overlap Resolution Engine for any day (using resolveDayCollisions)
  const handleAutoResolveOverlaps = useCallback(
    (dayKey: DayKey) => {
      setBlocksWithHistory((prev) => {
        const updated = resolveDayCollisions(
          prev,
          dayKey,
          plannerRules.bufferMinutesBetweenTasks
        );
        const dayName = DAYS.find((d) => d.id === dayKey)?.nameFa || dayKey;
        showToast(`تداخل‌های زمانی روز ${dayName} با موفقیت رفع و به صورت متوالی چیده شدند.`, 'success');
        return updated;
      }, 'رفع تداخل زمانی');
    },
    [plannerRules.bufferMinutesBetweenTasks, setBlocksWithHistory, showToast]
  );

  // Align all days across the whole week immediately
  const handleAlignAllDays = useCallback(() => {
    setBlocksWithHistory((prev) => {
      let current = [...prev];
      for (const day of DAYS) {
        current = resolveDayCollisions(current, day.id, plannerRules.bufferMinutesBetweenTasks);
      }
      showToast('تمام روزها با موفقیت ترازبندی شدند و هیچ دو کارتی هم‌پوشانی ندارند.', 'success');
      return current;
    }, 'ترازبندی کل هفته');
  }, [plannerRules.bufferMinutesBetweenTasks, setBlocksWithHistory, showToast]);

  // Unified 1-Click Copy & Paste Engine
  const handleCopyTemplateToClipboard = useCallback((tpl: BlockTemplate) => {
    setClipboardItem({
      type: 'template',
      title: tpl.title,
      subtitle: tpl.subtitle,
      category: tpl.category,
      durationMinutes: tpl.defaultDuration,
      note: tpl.description,
    });
    showToast(`«${tpl.title}» کپی شد! اکنون برای پیست، روی هر ساعت دلخواه از جدول کلیک کنید.`, 'success');
  }, [showToast]);

  const handleCopyBlock = useCallback((block: TimeBlock) => {
    setClipboardItem({
      type: 'block',
      title: block.title,
      subtitle: block.subtitle,
      category: block.category,
      durationMinutes: block.durationMinutes,
      note: block.note,
    });
    showToast(`«${block.title}» کپی شد! برای پیست، روی هر ساعت دلخواه در جدول تقویم کلیک کنید.`, 'success');
  }, [showToast]);

  const handleClearClipboard = useCallback(() => {
    setClipboardItem(null);
    showToast('حافظه کپی لغو شد.', 'info');
  }, [showToast]);

  const handlePasteClipboard = useCallback(
    (day: DayKey, startMinutes: number) => {
      if (!clipboardItem) return;

      const snapInterval = plannerRules.bufferMinutesBetweenTasks > 0 ? 5 : 15;
      const snappedMinutes = Math.round(startMinutes / snapInterval) * snapInterval;
      const maxAvailableMinutes = END_HOUR * 60 - snappedMinutes;
      const durationMinutes = Math.min(
        clipboardItem.durationMinutes,
        Math.max(15, maxAvailableMinutes)
      );

      const newBlock: TimeBlock = {
        id: `block-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        day,
        startMinutes: Math.max(START_HOUR * 60, snappedMinutes),
        durationMinutes,
        title: clipboardItem.title,
        subtitle: clipboardItem.subtitle,
        category: clipboardItem.category,
        note: clipboardItem.note,
        completed: false,
      };

      setBlocksWithHistory((prev) => {
        if (plannerRules.strictNonOverlap) {
          const { updatedBlocks, pushedCount } = cascadeInsertBlock(
            prev,
            newBlock,
            plannerRules.bufferMinutesBetweenTasks
          );
          if (pushedCount > 0) {
            showToast(
              `«${newBlock.title}» پیست شد و ${toFaDigits(pushedCount)} تسک بعدی متوالیاً به جلو شیفت یافتند.`,
              'info'
            );
          } else {
            showToast(`«${newBlock.title}» با موفقیت در جدول پیست شد.`);
          }
          return updatedBlocks;
        }
        showToast(`«${newBlock.title}» با موفقیت در جدول پیست شد.`);
        return [...prev, newBlock];
      }, `پیست «${newBlock.title}»`);
    },
    [clipboardItem, plannerRules.strictNonOverlap, plannerRules.bufferMinutesBetweenTasks, setBlocksWithHistory, showToast]
  );

  // Dragging template from sidebar bank
  const handleDragStartTemplate = (
    e: React.DragEvent,
    template: BlockTemplate
  ) => {
    e.dataTransfer.setData('text/template-data', JSON.stringify(template));
    e.dataTransfer.effectAllowed = 'copy';
  };

  // Dropping template into grid (with Strict Non-Overlap & Auto-Cascade)
  const handleDropNewBlock = (
    day: DayKey,
    startMinutes: number,
    template: BlockTemplate
  ) => {
    const snapInterval = plannerRules.bufferMinutesBetweenTasks > 0 ? 5 : 15;
    const snappedMinutes = Math.round(startMinutes / snapInterval) * snapInterval;
    const maxAvailableMinutes = END_HOUR * 60 - snappedMinutes;
    const durationMinutes = Math.min(
      template.defaultDuration,
      Math.max(15, maxAvailableMinutes)
    );

    const newBlock: TimeBlock = {
      id: `block-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      day,
      startMinutes: Math.max(START_HOUR * 60, snappedMinutes),
      durationMinutes,
      title: template.title,
      subtitle: template.subtitle,
      category: template.category,
      note: template.description,
      completed: false,
    };

    setBlocksWithHistory((prev) => {
      if (plannerRules.strictNonOverlap) {
        const { updatedBlocks, pushedCount } = cascadeInsertBlock(
          prev,
          newBlock,
          plannerRules.bufferMinutesBetweenTasks
        );
        if (pushedCount > 0) {
          showToast(
            `«${template.title}» اضافه شد و ${toFaDigits(pushedCount)} کارت بعدی متوالیاً به جلو منتقل شدند.`,
            'info'
          );
        } else {
          showToast(`«${template.title}» با موفقیت بدون تداخل به جدول اضافه شد.`);
        }
        return updatedBlocks;
      }
      showToast(`«${template.title}» با موفقیت به جدول اضافه شد.`);
      return [...prev, newBlock];
    }, `افزودن «${template.title}»`);
  };

  // Moving existing block (with Strict Non-Overlap & Auto-Cascade)
  const handleMoveBlock = (
    blockId: string,
    targetDay: DayKey,
    newStartMinutes: number
  ) => {
    setBlocksWithHistory((prev) => {
      if (plannerRules.strictNonOverlap) {
        const { updatedBlocks, pushedCount } = cascadeMoveBlock(
          prev,
          blockId,
          targetDay,
          newStartMinutes,
          plannerRules.bufferMinutesBetweenTasks
        );
        if (pushedCount > 0) {
          showToast(
            `کارت جابجا شد و ${toFaDigits(pushedCount)} تسک بعدی برای رفع تداخل به جلو منتقل شدند.`,
            'info'
          );
        } else {
          showToast('زمان بلوک با موفقیت تغییر یافت.');
        }
        return updatedBlocks;
      }

      return prev.map((b) => {
        if (b.id !== blockId) return b;
        const maxAvailable = END_HOUR * 60 - newStartMinutes;
        const safeDuration = Math.min(b.durationMinutes, Math.max(15, maxAvailable));
        return {
          ...b,
          day: targetDay,
          startMinutes: newStartMinutes,
          durationMinutes: safeDuration,
        };
      });
    }, 'جابجایی بلوک');
  };

  // Resizing block
  const handleResizeBlock = (blockId: string, newDurationMinutes: number) => {
    setBlocksWithHistory((prev) =>
      prev.map((b) =>
        b.id === blockId ? { ...b, durationMinutes: newDurationMinutes } : b
      ),
      'تغییر زمان بلوک'
    );
  };

  // Updating block from edit modal (with optional synchronization to all matching blocks)
  const handleUpdateBlock = (
    updatedBlock: TimeBlock,
    updateAllMatching = false,
    originalTitle?: string
  ) => {
    setBlocksWithHistory((prev) => {
      if (!updateAllMatching) {
        return prev.map((b) => (b.id === updatedBlock.id ? updatedBlock : b));
      }
      const matchTitle = originalTitle || updatedBlock.title;
      return prev.map((b) => {
        if (b.id === updatedBlock.id) return updatedBlock;
        if (b.title === matchTitle) {
          return {
            ...b,
            title: updatedBlock.title,
            subtitle: updatedBlock.subtitle,
            category: updatedBlock.category,
          };
        }
        return b;
      });
    }, `ویرایش «${updatedBlock.title}»`);
    showToast(
      updateAllMatching
        ? `تغییرات روی تمامی بلوک‌های مشابه «${updatedBlock.title}» اعمال گردید.`
        : `تغییرات «${updatedBlock.title}» با موفقیت ذخیره شد.`
    );
  };

  // Toggle completion status of a block
  const handleToggleBlockComplete = (blockId: string) => {
    setBlocksWithHistory((prev) =>
      prev.map((b) => (b.id === blockId ? { ...b, completed: !b.completed } : b)),
      'تغییر وضعیت انجام کارت'
    );
  };

  // Deleting block
  const handleDeleteBlock = (blockId: string) => {
    setBlocksWithHistory((prev) => prev.filter((b) => b.id !== blockId), 'حذف کارت');
    showToast('بلوک زمانی حذف گردید.', 'info');
  };

  // Duplicate block to another day
  const handleDuplicateBlock = (sourceBlock: TimeBlock, targetDay: DayKey) => {
    const duplicated: TimeBlock = {
      ...sourceBlock,
      id: `block-dup-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      day: targetDay,
      completed: false,
    };
    setBlocksWithHistory((prev) => [...prev, duplicated], `کپی «${sourceBlock.title}» به روز دیگر`);
    showToast(`بلوک با موفقیت در روز جدید کپی شد.`);
  };

  // Quick Add from sidebar to Saturday 09:00 or current
  const handleQuickAdd = (template: BlockTemplate) => {
    handleDropNewBlock('sat', 9 * 60, template);
  };

  // TEMPLATES BANK EDITING CAPABILITIES:
  // 1. Create or Save Template (with optional synchronization to existing schedule blocks)
  const handleSaveTemplate = (
    savedTemplate: BlockTemplate,
    updateMatchingBlocks = false,
    oldTitle?: string
  ) => {
    setTemplates((prev) => {
      const exists = prev.some((t) => t.id === savedTemplate.id);
      if (exists) {
        return prev.map((t) => (t.id === savedTemplate.id ? savedTemplate : t));
      }
      return [...prev, savedTemplate];
    });

    if (updateMatchingBlocks) {
      const searchTitle = oldTitle || savedTemplate.title;
      setBlocksWithHistory((prev) =>
        prev.map((b) => {
          if (b.title === searchTitle) {
            return {
              ...b,
              title: savedTemplate.title,
              subtitle: savedTemplate.subtitle,
              category: savedTemplate.category,
            };
          }
          return b;
        }),
        `به‌روزرسانی دسته‌جمعی «${searchTitle}»`
      );
      showToast(
        `الگو و تمامی بلوک‌های «${searchTitle}» در جدول با موفقیت به‌روزرسانی شدند.`
      );
    } else {
      showToast(`الگوی «${savedTemplate.title}» در بانک ذخیره شد.`);
    }
  };

  // 2. Open edit modal for a template
  const handleOpenEditTemplate = (template: BlockTemplate) => {
    setEditingTemplate(template);
    setIsTemplateModalOpen(true);
  };

  // 3. Open create new template modal
  const handleOpenCreateTemplate = () => {
    setEditingTemplate(null);
    setIsTemplateModalOpen(true);
  };

  // 4. Duplicate template in bank
  const handleDuplicateTemplate = (template: BlockTemplate) => {
    const duplicated: BlockTemplate = {
      ...template,
      id: `tmpl-custom-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title: `${template.title} (کپی)`,
    };
    setTemplates((prev) => [...prev, duplicated]);
    showToast(`الگوی «${duplicated.title}» تکثیر شد.`);
  };

  // 5. Delete template from bank
  const handleDeleteTemplate = (templateId: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== templateId));
    showToast('الگو از بانک حذف شد.', 'info');
  };

  // 6. Reset templates to default
  const handleResetDefaultTemplates = () => {
    setTemplates(INITIAL_TEMPLATES);
    showToast('بانک الگوها به وضعیت اولیه بازنشانی شد.');
  };

  // Apply JSON State from JsonModal (AI / Editor / Import)
  const handleApplyJsonState = (newState: {
    title?: string;
    weekRange?: string;
    blocks: TimeBlock[];
    templates?: BlockTemplate[];
    timePhases?: TimePhaseInfo[];
    weeklyNotes?: WeeklyTaskItem[];
    customCategoryColors?: Record<string, string>;
  }) => {
    if (newState.title) setPlannerTitle(newState.title);
    if (newState.weekRange) setWeekRange(newState.weekRange);
    setBlocksWithHistory(newState.blocks, 'ورود فایل یا دستور JSON');
    if (newState.templates) setTemplates(newState.templates);
    if (newState.timePhases) setTimePhases(newState.timePhases);
    if (newState.weeklyNotes) setWeeklyNotes(newState.weeklyNotes);
    if (newState.customCategoryColors) setCustomCategoryColors(newState.customCategoryColors);
  };

  // Late Wake-up Shift Engine (Crucial Anti-Fragile Requirement)
  const handleApplyLateShift = (
    day: DayKey,
    shiftMinutes: number,
    afterMinutes: number
  ) => {
    setBlocksWithHistory((prev) =>
      prev.map((b) => {
        if (b.day !== day || b.startMinutes < afterMinutes) return b;
        const newStart = b.startMinutes + shiftMinutes;
        if (newStart >= END_HOUR * 60) {
          return {
            ...b,
            startMinutes: (END_HOUR - 1) * 60,
            durationMinutes: 30,
          };
        }
        const maxDuration = END_HOUR * 60 - newStart;
        const safeDuration = Math.min(b.durationMinutes, maxDuration);
        return {
          ...b,
          startMinutes: newStart,
          durationMinutes: safeDuration,
        };
      }),
      'شیفت روزانه (بیداری دیرهنگام)'
    );
    showToast(
      'روز شما با موفقیت شیفت داده شد! به خودت سخت نگیر: ۱ همیشه از ۰ بزرگ‌تره.',
      'success'
    );
  };

  // Reset to sample AI/Software student schedule
  const handleResetSample = () => {
    if (confirm('آیا می‌خواهید برنامه نمونه پیش‌فرض را بارگذاری کنید؟')) {
      setBlocksWithHistory(INITIAL_SAMPLE_BLOCKS, 'بارگذاری نمونه پیش‌فرض');
      setTemplates(INITIAL_TEMPLATES);
      setPlannerTitle('برنامه‌ریز هفتگی تایم‌باکسینگ (Anti-Fragile)');
      setWeekRange('اسپرینت لینوکس و مدل‌سازی یادگیری عمیق');
      showToast('برنامه نمونه مهندس هوش مصنوعی با موفقیت بارگذاری شد.');
    }
  };

  // Clear all (Two-step confirmation with mandatory JSON backup safeguard)
  const handleClearAll = () => {
    setIsClearModalOpen(true);
  };

  const handleConfirmClear = () => {
    setBlocksWithHistory([], 'پاک‌سازی کل هفته');
    setIsClearModalOpen(false);
    showToast('تمامی بلوک‌های هفته پاک شدند. پشتیبان JSON در سیستم شما ذخیره گردید.', 'info');
  };

  // Insert smart break into a block (with guaranteed mathematical non-overlapping logic)
  const handleConfirmInsertBreak = (params: {
    originalBlockId: string;
    breakDurationMinutes: number;
    breakPositionMinutes: number;
    breakTitle: string;
    breakSubtitle: string;
    mode: 'split' | 'shift';
  }) => {
    const target = blocks.find((b) => b.id === params.originalBlockId);
    if (!target) return;

    const breakBlock: TimeBlock = {
      id: `break-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      day: target.day,
      startMinutes: target.startMinutes + params.breakPositionMinutes,
      durationMinutes: params.breakDurationMinutes,
      title: params.breakTitle,
      subtitle: params.breakSubtitle,
      category: 'gaming',
      completed: false,
      note: 'استراحت و بازیابی تمرکز ذهنی',
    };

    if (params.mode === 'split') {
      const part1Duration = params.breakPositionMinutes;
      const part2Duration = target.durationMinutes - part1Duration - params.breakDurationMinutes;

      const part1: TimeBlock = {
        ...target,
        id: target.id,
        durationMinutes: part1Duration,
      };

      const newBlocksList: TimeBlock[] = [];
      blocks.forEach((b) => {
        if (b.id === target.id) {
          newBlocksList.push(part1);
          newBlocksList.push(breakBlock);
          if (part2Duration > 0) {
            const part2: TimeBlock = {
              ...target,
              id: `block-part2-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
              startMinutes: breakBlock.startMinutes + breakBlock.durationMinutes,
              durationMinutes: part2Duration,
              completed: false,
              subtitle: target.subtitle ? `${target.subtitle} (بخش دوم)` : 'بخش دوم',
            };
            newBlocksList.push(part2);
          }
        } else {
          newBlocksList.push(b);
        }
      });

      setBlocksWithHistory(newBlocksList, `درج استراحت در «${target.title}»`);
      showToast(`استراحت ${params.breakDurationMinutes} دقیقه‌ای با حفظ دقیق ساعات در جدول درج شد.`);
    } else {
      // shift mode
      const breakStart = target.startMinutes + target.durationMinutes;
      breakBlock.startMinutes = breakStart;

      const updatedBlocks = blocks.map((b) => {
        if (b.day === target.day && b.id !== target.id && b.startMinutes >= breakStart) {
          return {
            ...b,
            startMinutes: b.startMinutes + params.breakDurationMinutes,
          };
        }
        return b;
      });

      setBlocksWithHistory([...updatedBlocks, breakBlock], `درج استراحت و شیفت «${target.title}»`);
      showToast(`استراحت ${params.breakDurationMinutes} دقیقه‌ای درج و برنامه‌های پس از آن به جلو شیفت داده شدند.`);
    }
  };

  // Intercept keyboard shortcuts (Ctrl+Z for Undo, Ctrl+Y or Ctrl+Shift+Z for Redo, Ctrl+P for Print, F/Esc for Fullscreen)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check if user is typing in an input or textarea
      const activeEl = document.activeElement;
      const isInputActive =
        activeEl instanceof HTMLInputElement ||
        activeEl instanceof HTMLTextAreaElement ||
        activeEl?.getAttribute('contenteditable') === 'true';

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (!isInputActive) {
          e.preventDefault();
          if (e.shiftKey) {
            handleRedo();
          } else {
            handleUndo();
          }
          return;
        }
      }

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        if (!isInputActive) {
          e.preventDefault();
          handleRedo();
          return;
        }
      }

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        setIsPrintModalOpen(true);
        return;
      }

      if (!isInputActive) {
        if (e.key === 'f' || e.key === 'F') {
          e.preventDefault();
          setIsFullscreenGrid((prev) => !prev);
        } else if (e.key === 'Escape') {
          setIsFullscreenGrid(false);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-100/60 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-['Vazirmatn',sans-serif]">
      {/* Dedicated Fullscreen Grid Mode (User requested: ONLY the schedule table occupying the entire screen) */}
      {isFullscreenGrid && (
        <div className="fixed inset-0 z-50 bg-white dark:bg-slate-950 flex flex-col w-screen h-screen overflow-hidden">
          <TimeGrid
            blocks={blocks}
            onUpdateBlock={handleUpdateBlock}
            onDeleteBlock={handleDeleteBlock}
            onSelectBlock={(b) => setSelectedBlock(b)}
            onDropNewBlock={handleDropNewBlock}
            onMoveBlock={handleMoveBlock}
            onResizeBlock={handleResizeBlock}
            plannerTitle={plannerTitle}
            weekRange={weekRange}
            isFullscreen={true}
            onToggleFullscreen={() => setIsFullscreenGrid(false)}
            onOpenInsertBreak={(b) => {
              setBreakTargetBlock(b);
              setIsInsertBreakOpen(true);
            }}
            timePhases={timePhases}
            onOpenCircadianModal={() => setIsCircadianModalOpen(true)}
            customCategoryColors={customCategoryColors}
            onAutoResolveOverlaps={handleAutoResolveOverlaps}
            clipboardItem={clipboardItem}
            onPasteClipboard={handlePasteClipboard}
            onCopyBlock={handleCopyBlock}
            onClearClipboard={handleClearClipboard}
          />
        </div>
      )}

      {/* Top Header with Daily Report, Special Weekly Report, Circadian & Database Settings */}
      <Header
        plannerTitle={plannerTitle}
        onUpdateTitle={setPlannerTitle}
        weekRange={weekRange}
        onUpdateWeekRange={setWeekRange}
        onSaveJSON={() => setIsJsonModalOpen(true)}
        onLoadJSON={() => setIsJsonModalOpen(true)}
        onPrint={() => setIsPrintModalOpen(true)}
        onOpenDailyReport={() => setIsDailyReportOpen(true)}
        onOpenSpecialReport={() => setIsSpecialReportOpen(true)}
        onOpenJsonModal={() => setIsJsonModalOpen(true)}
        onOpenOfflineExport={() => setIsOfflineModalOpen(true)}
        onResetSample={handleResetSample}
        onClearAll={handleClearAll}
        onOpenLateShift={() => setIsLateShiftOpen(true)}
        onToggleStats={() => setShowStats(!showStats)}
        showStats={showStats}
        isFullscreen={isFullscreenGrid}
        onToggleFullscreen={() => setIsFullscreenGrid((prev) => !prev)}
        onOpenCircadian={() => setIsCircadianModalOpen(true)}
        onOpenDatabase={() => setIsDatabaseModalOpen(true)}
        onOpenPlannerRules={() => setIsPlannerRulesOpen(true)}
        darkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode((prev) => !prev)}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={undoStack.length > 0}
        canRedo={redoStack.length > 0}
        undoCount={undoStack.length}
        redoCount={redoStack.length}
        onOpenSleepMovie={() => setIsSleepMovieModalOpen(true)}
      />

      {/* Week Balance Neuro Dashboard (Collapsible & Fully Editable) */}
      {showStats && (
        <WeekStats
          blocks={blocks}
          onClose={() => setShowStats(false)}
          weeklyGoals={weeklyGoals}
          onOpenGoalsModal={() => setIsWeekGoalsOpen(true)}
        />
      )}

      {/* Main Workspace: Sidebar Bank + Time Grid */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Sidebar Bank of Blocks (Fully Editable) */}
        <SidebarBank
          templates={templates}
          onOpenCreateTemplate={handleOpenCreateTemplate}
          onEditTemplate={handleOpenEditTemplate}
          onDuplicateTemplate={handleDuplicateTemplate}
          onDeleteTemplate={handleDeleteTemplate}
          onResetDefaultTemplates={handleResetDefaultTemplates}
          onQuickAdd={handleQuickAdd}
          onDragStartTemplate={handleDragStartTemplate}
          onCopyTemplateToClipboard={handleCopyTemplateToClipboard}
        />

        {/* 7-Day Timeboxing Grid Canvas */}
        <TimeGrid
          blocks={blocks}
          onUpdateBlock={handleUpdateBlock}
          onDeleteBlock={handleDeleteBlock}
          onSelectBlock={(b) => setSelectedBlock(b)}
          onDropNewBlock={handleDropNewBlock}
          onMoveBlock={handleMoveBlock}
          onResizeBlock={handleResizeBlock}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          isFullscreen={false}
          onToggleFullscreen={() => setIsFullscreenGrid(true)}
          onOpenInsertBreak={(b) => {
            setBreakTargetBlock(b);
            setIsInsertBreakOpen(true);
          }}
          timePhases={timePhases}
          onOpenCircadianModal={() => setIsCircadianModalOpen(true)}
          customCategoryColors={customCategoryColors}
          onAutoResolveOverlaps={handleAutoResolveOverlaps}
          clipboardItem={clipboardItem}
          onPasteClipboard={handlePasteClipboard}
          onCopyBlock={handleCopyBlock}
          onClearClipboard={handleClearClipboard}
        />
      </div>

      {/* Weekly Neuro-Notes & Strategic Brain Dump Section */}
      <WeeklyNotesSection
        notes={weeklyNotes}
        onUpdateNotes={setWeeklyNotes}
        onShowToast={showToast}
      />

      {/* Block Edit Modal */}
      {selectedBlock && (
        <BlockModal
          key={selectedBlock.id}
          block={selectedBlock}
          isOpen={true}
          onClose={() => setSelectedBlock(null)}
          onSave={handleUpdateBlock}
          onDelete={handleDeleteBlock}
          onDuplicate={handleDuplicateBlock}
          onOpenInsertBreak={(b) => {
            setBreakTargetBlock(b);
            setIsInsertBreakOpen(true);
          }}
        />
      )}

      {/* Late Wake-up / Forgiving Shift Modal */}
      {isLateShiftOpen && (
        <LateShiftModal
          isOpen={true}
          onClose={() => setIsLateShiftOpen(false)}
          blocks={blocks}
          onApplyShift={handleApplyLateShift}
        />
      )}

      {/* Comprehensive Template Modal (Create, Edit, Delete, Duplicate) */}
      {isTemplateModalOpen && (
        <TemplateModal
          isOpen={true}
          templateToEdit={editingTemplate}
          onClose={() => {
            setIsTemplateModalOpen(false);
            setEditingTemplate(null);
          }}
          onSaveTemplate={handleSaveTemplate}
          onDeleteTemplate={handleDeleteTemplate}
          onDuplicateTemplate={handleDuplicateTemplate}
        />
      )}

      {/* Daily Report Modal (Structured Text Briefing + High-DPI PNG Card + At-a-Glance) */}
      {isDailyReportOpen && (
        <DailyReportModal
          isOpen={true}
          onClose={() => setIsDailyReportOpen(false)}
          blocks={blocks}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          onShowToast={showToast}
          onToggleComplete={handleToggleBlockComplete}
        />
      )}

      {/* 2-Step Clear All & Mandatory JSON Backup Safeguard Modal */}
      {isClearModalOpen && (
        <ClearConfirmModal
          isOpen={true}
          onClose={() => setIsClearModalOpen(false)}
          onConfirmClear={handleConfirmClear}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          blocks={blocks}
          templates={templates}
          onShowToast={showToast}
        />
      )}

      {/* Run on Personal Computer / Standalone HTML & Scripts Modal */}
      {isOfflineModalOpen && (
        <OfflineExportModal
          isOpen={true}
          onClose={() => setIsOfflineModalOpen(false)}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          blocks={blocks}
          templates={templates}
          onShowToast={showToast}
        />
      )}

      {/* AI & JSON Architecture Modal (AI Prompts, Live Editor, Validation, Import/Export) */}
      {isJsonModalOpen && (
        <JsonModal
          isOpen={true}
          onClose={() => setIsJsonModalOpen(false)}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          blocks={blocks}
          templates={templates}
          timePhases={timePhases}
          weeklyNotes={weeklyNotes}
          onApplyJsonState={handleApplyJsonState}
          onShowToast={showToast}
        />
      )}

      {/* Circadian Rhythm & Biological Energy Schedule Modal */}
      {isCircadianModalOpen && (
        <CircadianModal
          isOpen={true}
          onClose={() => setIsCircadianModalOpen(false)}
          phases={timePhases}
          onSavePhases={(updated) => {
            setTimePhases(updated);
            showToast('ریتم روان‌شناختی شبانه‌روز با موفقیت ذخیره شد.', 'success');
          }}
          onResetDefault={() => {
            setTimePhases(TIME_PHASES);
            showToast('ریتم روان‌شناختی به تنظیمات استاندارد بازنشانی شد.');
          }}
        />
      )}

      {/* 5-Day Dual-Engine Database & Local/Cloud Backup Safeguard Modal */}
      {isDatabaseModalOpen && (
        <DatabaseSettingsModal
          isOpen={true}
          onClose={() => setIsDatabaseModalOpen(false)}
          totalBlocks={blocks.length}
          totalTemplates={templates.length}
          totalNotes={weeklyNotes.length}
          customCategoryColors={customCategoryColors}
          onUpdateCategoryColor={(catKey, hexColor) => {
            setCustomCategoryColors((prev) => ({ ...prev, [catKey]: hexColor }));
          }}
          onResetCategoryColors={() => {
            setCustomCategoryColors({});
            showToast('رنگ دسته‌بندی‌ها به حالت پیش‌فرض بازنشانی شد.');
          }}
          onClearDatabase={() => {
            setBlocks([]);
            setTemplates(INITIAL_TEMPLATES);
            setWeeklyNotes(INITIAL_WEEKLY_NOTES);
            setCustomCategoryColors({});
            PlannerStorageService.clearDatabase();
            showToast('تمام اطلاعات پایگاه‌داده با موفقیت پاک‌سازی شد.', 'warn');
          }}
          onDownloadBackup={() => {
            PlannerStorageService.exportBackupFile({
              version: '3.0.0',
              title: plannerTitle,
              weekRange,
              updatedAt: new Date().toISOString(),
              blocks,
              templates,
              timePhases,
              weeklyNotes,
              customCategoryColors,
            });
            showToast('فایل پشتیبان کامل با موفقیت دانلود شد.', 'success');
          }}
          onRestoreBackup={async (file) => {
            try {
              const restored = await PlannerStorageService.importBackupFile(file);
              if (restored) {
                if (restored.title) setPlannerTitle(restored.title);
                if (restored.weekRange) setWeekRange(restored.weekRange);
                if (restored.blocks) setBlocks(restored.blocks);
                if (restored.templates) setTemplates(restored.templates);
                if (restored.timePhases) setTimePhases(restored.timePhases);
                if (restored.weeklyNotes) setWeeklyNotes(restored.weeklyNotes);
                if (restored.customCategoryColors) setCustomCategoryColors(restored.customCategoryColors);
                showToast('پشتیبان با موفقیت بر روی دیتابیس بازیابی شد.', 'success');
              }
            } catch (err) {
              console.error(err);
              showToast('خطا در خواندن فایل پشتیبان. لطفاً فایل معتبر JSON انتخاب کنید.', 'warn');
            }
          }}
          onShowToast={showToast}
        />
      )}

      {/* Professional Print & PDF Export Modal */}
      {isPrintModalOpen && (
        <PrintModal
          isOpen={true}
          onClose={() => setIsPrintModalOpen(false)}
          blocks={blocks}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          onUpdateBlocks={(newBlocks) => {
            setBlocks(newBlocks);
            showToast('تمام تداخل‌های زمانی با موفقیت برطرف و تراز شدند.', 'success');
          }}
        />
      )}

      {/* Special Weekly Activity Intelligence & Card Report Modal */}
      {isSpecialReportOpen && (
        <SpecialWeeklyReportModal
          isOpen={true}
          onClose={() => setIsSpecialReportOpen(false)}
          blocks={blocks}
          plannerTitle={plannerTitle}
          weekRange={weekRange}
          onShowToast={showToast}
          onToggleComplete={handleToggleBlockComplete}
        />
      )}

      {/* Smart Break Insertion Modal (With guaranteed non-overlapping math) */}
      {isInsertBreakOpen && breakTargetBlock && (
        <InsertBreakModal
          isOpen={true}
          block={breakTargetBlock}
          onClose={() => {
            setIsInsertBreakOpen(false);
            setBreakTargetBlock(null);
          }}
          onConfirmBreak={handleConfirmInsertBreak}
        />
      )}

      {/* Smart Rules & Anti-Collision Engine Configuration Modal */}
      {isPlannerRulesOpen && (
        <PlannerRulesModal
          isOpen={true}
          onClose={() => setIsPlannerRulesOpen(false)}
          rules={plannerRules}
          onSaveRules={(newRules) => {
            setPlannerRules(newRules);
            showToast('تنظیمات قوانین برنامه‌ریزی با موفقیت ذخیره شد.', 'success');
          }}
          onAlignAllDays={handleAlignAllDays}
          hasAnyOverlaps={hasAnyOverlaps}
        />
      )}

      {/* Weekly 4 Pillars & Goals Customization Modal */}
      {isWeekGoalsOpen && (
        <WeekGoalsModal
          isOpen={true}
          onClose={() => setIsWeekGoalsOpen(false)}
          goals={weeklyGoals}
          onSaveGoals={(newGoals) => {
            setWeeklyGoals(newGoals);
            showToast('اهداف و عناوین ۴ رکن با موفقیت به‌روزرسانی شد.', 'success');
          }}
        />
      )}

      {/* Automatic Sleep & Movie Arrangement Intelligence Modal */}
      <AutoSleepMovieModal
        isOpen={isSleepMovieModalOpen}
        onClose={() => setIsSleepMovieModalOpen(false)}
        onApply={handleApplySleepAndMovie}
        onClearSleepAndMovie={handleClearSleepAndMovie}
        existingBlocks={blocks}
      />

      {/* Floating Reassuring Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 left-5 z-50 no-print animate-bounce-subtle">
          <div
            className={`px-4 py-3 rounded-xl shadow-lg border flex items-center gap-2.5 text-xs font-semibold backdrop-blur-md ${
              toast.type === 'success'
                ? 'bg-emerald-900/90 text-white border-emerald-700'
                : toast.type === 'warn'
                ? 'bg-amber-900/90 text-white border-amber-700'
                : 'bg-slate-900/90 text-white border-slate-700'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
            ) : toast.type === 'warn' ? (
              <AlertCircle className="w-4 h-4 text-amber-300 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-sky-300 shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}
