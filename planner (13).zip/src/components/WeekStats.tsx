import React from 'react';
import { X, Sparkles, Brain, Award, Activity, HeartHandshake } from 'lucide-react';
import { TimeBlock, CategoryKey } from '../types';
import { formatDurationFa, toFaDigits } from '../constants/plannerConfig';
import { CategoryIcon } from './CategoryIcon';

interface WeekStatsProps {
  blocks: TimeBlock[];
  isOpen: boolean;
  onClose: () => void;
}

export const WeekStats: React.FC<WeekStatsProps> = ({ blocks, isOpen, onClose }) => {
  if (!isOpen) return null;

  // Calculate total minutes per category
  const categoryTotals: Record<CategoryKey, number> = {
    university: 0,
    work: 0,
    python: 0,
    pytorch: 0,
    recovery: 0,
    gaming: 0,
    habit: 0,
    meeting: 0,
    custom: 0,
  };

  let totalPlannedMinutes = 0;
  let completedMinutes = 0;

  blocks.forEach((block) => {
    categoryTotals[block.category] =
      (categoryTotals[block.category] || 0) + block.durationMinutes;
    totalPlannedMinutes += block.durationMinutes;
    if (block.completed) {
      completedMinutes += block.durationMinutes;
    }
  });

  const deepWorkMinutes = categoryTotals.python + categoryTotals.pytorch;
  const workMinutes = categoryTotals.work + categoryTotals.meeting;
  const restMinutes = categoryTotals.recovery + categoryTotals.gaming;
  const universityMinutes = categoryTotals.university;

  const completionRate =
    totalPlannedMinutes > 0 ? Math.round((completedMinutes / totalPlannedMinutes) * 100) : 0;

  return (
    <div className="bg-slate-950/90 backdrop-blur-2xl border-b border-slate-800/90 px-3 sm:px-5 py-4 no-print shadow-2xl transition-all animate-in fade-in duration-300 text-slate-100">
      <div className="max-w-[1920px] mx-auto">
        {/* Top Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3.5 pb-2.5 border-b border-slate-800/80">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500/20 via-purple-500/20 to-teal-500/20 text-indigo-400 border border-indigo-400/30 flex items-center justify-center shadow-lg shadow-indigo-950/50 ring-1 ring-indigo-500/20 shrink-0">
              <Brain className="w-5 h-5 stroke-[2.2] animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2.5 flex-wrap">
                <h3 className="text-sm sm:text-base font-black text-white tracking-tight truncate">
                  تحلیل بار شناختی و تعادل هفتگی (Neuro-Balance Dashboard)
                </h3>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 font-extrabold border border-emerald-500/30 flex items-center gap-1.5 shadow-2xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>
                    {toFaDigits(completionRate)}٪ انجام‌شده ({formatDurationFa(completedMinutes)})
                  </span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 font-medium hidden sm:block">
                ارزیابی تعادل سیستم عصبی، بار توجه پایدار و توزیع انرژی زیستی در طول هفته
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer shrink-0 active:scale-90"
            title="بستن داشبورد تعادل هفتگی"
            aria-label="بستن داشبورد تعادل هفتگی"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* 4 Pillars Summary Cards (Deep Slate Translucent Panels) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          {/* 1. Deep Work (AI & Python) - Neon Violet Identity */}
          <div className="group relative p-3.5 rounded-2xl bg-gradient-to-br from-purple-950/40 via-slate-900/80 to-slate-900/90 border border-purple-500/30 hover:border-purple-400/60 shadow-lg shadow-purple-950/20 hover:shadow-purple-900/30 transition-all duration-300 hover:-translate-y-0.5">
            <div className="absolute top-0 right-6 w-16 h-0.5 bg-gradient-to-r from-transparent via-purple-400 to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />
            <div className="flex items-center justify-between text-xs text-purple-300 font-black mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-purple-400 shadow-xs shadow-purple-400" />
                <span>کار عمیق (AI & Python)</span>
              </span>
              <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-300 ring-1 ring-purple-500/30">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl font-black text-white font-mono tracking-tight my-0.5">
              {formatDurationFa(deepWorkMinutes)}
            </div>
            <p className="text-[11px] text-purple-300/80 font-medium">
              پایتون پیشرفته + مدل‌سازی PyTorch
            </p>
          </div>

          {/* 2. Work Project (Linux/Git) - Electric Blue / Cyan Identity */}
          <div className="group relative p-3.5 rounded-2xl bg-gradient-to-br from-sky-950/40 via-slate-900/80 to-slate-900/90 border border-sky-500/30 hover:border-sky-400/60 shadow-lg shadow-sky-950/20 hover:shadow-sky-900/30 transition-all duration-300 hover:-translate-y-0.5">
            <div className="absolute top-0 right-6 w-16 h-0.5 bg-gradient-to-r from-transparent via-sky-400 to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />
            <div className="flex items-center justify-between text-xs text-sky-300 font-black mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-sky-400 shadow-xs shadow-sky-400" />
                <span>پروژه کاری (Linux/Git)</span>
              </span>
              <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-300 ring-1 ring-sky-500/30">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl font-black text-white font-mono tracking-tight my-0.5">
              {formatDurationFa(workMinutes)}
            </div>
            <p className="text-[11px] text-sky-300/80 font-medium">
              تسک‌های فریلنس و جلسات سینک
            </p>
          </div>

          {/* 3. University & Path - Rose / Coral Identity */}
          <div className="group relative p-3.5 rounded-2xl bg-gradient-to-br from-rose-950/40 via-slate-900/80 to-slate-900/90 border border-rose-500/30 hover:border-rose-400/60 shadow-lg shadow-rose-950/20 hover:shadow-rose-900/30 transition-all duration-300 hover:-translate-y-0.5">
            <div className="absolute top-0 right-6 w-16 h-0.5 bg-gradient-to-r from-transparent via-rose-400 to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />
            <div className="flex items-center justify-between text-xs text-rose-300 font-black mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-400 shadow-xs shadow-rose-400" />
                <span>دانشگاه و مسیر</span>
              </span>
              <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 ring-1 ring-rose-500/30">
                <CategoryIcon category="university" className="w-4 h-4 text-rose-300" />
              </div>
            </div>
            <div className="text-xl font-black text-white font-mono tracking-tight my-0.5">
              {formatDurationFa(universityMinutes)}
            </div>
            <p className="text-[11px] text-rose-300/80 font-medium">
              کلاس‌ها و محدودیت‌های قطعی
            </p>
          </div>

          {/* 4. Rest & Dopamine - Emerald / Mint Identity */}
          <div className="group relative p-3.5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900/80 to-slate-900/90 border border-emerald-500/30 hover:border-emerald-400/60 shadow-lg shadow-emerald-950/20 hover:shadow-emerald-900/30 transition-all duration-300 hover:-translate-y-0.5">
            <div className="absolute top-0 right-6 w-16 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />
            <div className="flex items-center justify-between text-xs text-emerald-300 font-black mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-xs shadow-emerald-400" />
                <span>ریکاوری و دوپامین</span>
              </span>
              <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-500/30">
                <CategoryIcon category="recovery" className="w-4 h-4 text-emerald-300" />
              </div>
            </div>
            <div className="text-xl font-black text-white font-mono tracking-tight my-0.5">
              {formatDurationFa(restMinutes)}
            </div>
            <p className="text-[11px] text-emerald-300/80 font-medium">
              ناهار، تنفس، قدم زدن و استراحت کامل
            </p>
          </div>
        </div>

        {/* Visual Progress Breakdown Bar & Balance Indicator */}
        <div className="p-3 rounded-2xl bg-slate-900/70 border border-slate-800/90 space-y-2 shadow-inner">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-300 font-bold flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-400" />
              <span>توزیع زمان در هفته (مجموع: {formatDurationFa(totalPlannedMinutes)})</span>
            </span>
            <span
              className={`font-black px-2.5 py-0.5 rounded-full border text-[11px] flex items-center gap-1.5 shadow-2xs ${
                restMinutes >= 360
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>
                {restMinutes >= 360 ? 'تعادل عصبی عالی' : 'نیاز به اضافه کردن زمان استراحت'}
              </span>
            </span>
          </div>

          {/* Segmented Multi-Color Progress Bar */}
          <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden flex p-0.5 border border-slate-800/80 shadow-inner">
            {totalPlannedMinutes > 0 && (
              <>
                <div
                  style={{ width: `${(deepWorkMinutes / totalPlannedMinutes) * 100}%` }}
                  className="bg-gradient-to-r from-purple-500 to-indigo-500 rounded-sm transition-all duration-500 shadow-xs shadow-purple-500/40"
                  title={`کار عمیق: ${formatDurationFa(deepWorkMinutes)}`}
                />
                <div
                  style={{ width: `${(workMinutes / totalPlannedMinutes) * 100}%` }}
                  className="bg-gradient-to-r from-sky-500 to-cyan-500 rounded-sm transition-all duration-500 shadow-xs shadow-sky-500/40"
                  title={`پروژه کاری: ${formatDurationFa(workMinutes)}`}
                />
                <div
                  style={{ width: `${(universityMinutes / totalPlannedMinutes) * 100}%` }}
                  className="bg-gradient-to-r from-rose-500 to-pink-500 rounded-sm transition-all duration-500 shadow-xs shadow-rose-500/40"
                  title={`دانشگاه: ${formatDurationFa(universityMinutes)}`}
                />
                <div
                  style={{ width: `${(restMinutes / totalPlannedMinutes) * 100}%` }}
                  className="bg-gradient-to-r from-emerald-500 to-teal-400 rounded-sm transition-all duration-500 shadow-xs shadow-emerald-500/40"
                  title={`ریکاوری و تفریح: ${formatDurationFa(restMinutes)}`}
                />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

