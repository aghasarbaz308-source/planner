import React, { useRef, useState } from 'react';
import {
  Calendar,
  Save,
  FileUp,
  Printer,
  Sparkles,
  BarChart3,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Code2,
  Minimize2,
  Maximize2,
  Trash2,
  Laptop,
  CheckCircle2,
  Clock,
  ChevronDown,
  ShieldAlert,
  Zap,
  Undo2,
  Redo2,
  Plus,
  BookOpen,
  GraduationCap,
  Bell,
  Sliders,
  Palette,
  HeartHandshake,
  Database,
  BrainCircuit,
  Download,
  Upload,
  HardDrive,
  Flame,
  Layers,
  Activity,
} from 'lucide-react';
import { MOTIVATIONAL_QUOTES, toFaDigits } from '../constants/plannerConfig';
import {
  dateToJalali,
  JALALI_MONTH_NAMES,
} from '../utils/jalaliCalendar';

interface HeaderProps {
  plannerTitle: string;
  onUpdateTitle: (newTitle: string) => void;
  weekRange: string;
  onUpdateWeekRange: (newRange: string) => void;
  onSaveJSON: () => void;
  onLoadJSON: (file: File) => void;
  onPrint: () => void;
  onOpenDailyReport: () => void;
  onOpenSpecialReport: () => void;
  onOpenJsonModal: () => void;
  onOpenOfflineExport: () => void;
  onResetSample: () => void;
  onClearAll: () => void;
  onOpenLateShift: () => void;
  onOpenEmergencyRecovery: () => void;
  onOpenTutorial: () => void;
  onOpenReminderSettings: () => void;
  onOpenCategoryManager: () => void;
  onOpenAuditHistory: () => void;
  onOpenDatabaseSettings?: () => void;
  onOpenFocusMode?: () => void;
  onOpenConflictResolver?: () => void;
  onOpenAiPlanner?: () => void;
  conflictsCount?: number;
  activeBlockTitle?: string;
  slotInterval: number;
  onToggleSlotInterval: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onToggleStats?: () => void;
  showStats?: boolean;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
  currentDate?: Date;
  onOpenCalendar?: () => void;
  onOpenCreateWeek?: () => void;
  onPrevWeek?: () => void;
  onNextWeek?: () => void;
  savedWeeksCount?: number;
  totalBlocksCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  plannerTitle,
  onUpdateTitle,
  weekRange,
  onUpdateWeekRange,
  onSaveJSON,
  onLoadJSON,
  onPrint,
  onOpenDailyReport,
  onOpenSpecialReport,
  onOpenJsonModal,
  onOpenOfflineExport,
  onResetSample,
  onClearAll,
  onOpenLateShift,
  onOpenEmergencyRecovery,
  onOpenTutorial,
  onOpenReminderSettings,
  onOpenCategoryManager,
  onOpenAuditHistory,
  onOpenDatabaseSettings,
  onOpenFocusMode,
  onOpenConflictResolver,
  onOpenAiPlanner,
  conflictsCount = 0,
  activeBlockTitle,
  slotInterval,
  onToggleSlotInterval,
  onUndo,
  onRedo,
  canUndo = false,
  canRedo = false,
  onToggleStats,
  showStats,
  isFullscreen = false,
  onToggleFullscreen,
  currentDate = new Date(),
  onOpenCalendar,
  onOpenCreateWeek,
  onPrevWeek,
  onNextWeek,
  savedWeeksCount = 1,
  totalBlocksCount = 0,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [reportsMenuOpen, setReportsMenuOpen] = useState(false);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);

  const jDate = dateToJalali(currentDate);
  const jalaliMonthName = JALALI_MONTH_NAMES[jDate.jm - 1];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onLoadJSON(file);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <header className="bg-slate-900/95 backdrop-blur-xl border-b border-slate-800/80 sticky top-0 z-40 shadow-xl no-print transition-all text-slate-100">
      {/* 1. TOP EXECUTIVE RIBBON: COMPASSIONATE RECOVERY, UNDO/REDO & MOTTO */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 px-3 sm:px-5 py-1.5 text-xs flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-800/60 shadow-inner">
        {/* Anti-fragile Motivational Mantra */}
        <div className="flex items-center gap-2.5 min-w-0 max-w-2xl py-0.5">
          <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30 shadow-xs">
            <HeartHandshake className="w-3.5 h-3.5 animate-pulse" />
          </div>
          <p className="font-medium truncate text-[11px] sm:text-xs text-slate-300 leading-snug">
            <span className="font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300 ml-1">
              روانشناسی ضدشکننده:
            </span>
            <span className="text-slate-200">{MOTIVATIONAL_QUOTES[0]}</span>
          </p>
        </div>

        {/* Action Controls: Undo/Redo & Fast Compassionate Recovery */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* History Undo / Redo */}
          <div className="flex items-center bg-slate-800/90 rounded-lg p-0.5 border border-slate-700/60 shadow-xs">
            {onUndo && (
              <button
                type="button"
                onClick={onUndo}
                disabled={!canUndo}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                  canUndo
                    ? 'bg-slate-700/90 hover:bg-slate-600 text-white shadow-2xs hover:scale-102 active:scale-95'
                    : 'text-slate-500 cursor-not-allowed opacity-40'
                }`}
                title="بازگشت تغییرات قبلی (Ctrl+Z)"
              >
                <Undo2 className="w-3 h-3 stroke-[2.5]" />
                <span className="hidden xs:inline">Undo</span>
              </button>
            )}

            {onRedo && (
              <button
                type="button"
                onClick={onRedo}
                disabled={!canRedo}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                  canRedo
                    ? 'bg-slate-700/90 hover:bg-slate-600 text-white shadow-2xs hover:scale-102 active:scale-95'
                    : 'text-slate-500 cursor-not-allowed opacity-40'
                }`}
                title="انجام مجدد (Ctrl+Y)"
              >
                <Redo2 className="w-3 h-3 stroke-[2.5]" />
                <span className="hidden xs:inline">Redo</span>
              </button>
            )}
          </div>

          <div className="h-4 w-px bg-slate-800 mx-0.5" />

          {/* Late Shift Button */}
          <button
            type="button"
            onClick={onOpenLateShift}
            className="group flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-amber-500/20 to-amber-600/20 hover:from-amber-500/30 hover:to-amber-600/30 text-amber-300 hover:text-amber-200 border border-amber-500/40 rounded-lg text-[11px] font-black transition-all cursor-pointer hover:shadow-xs hover:shadow-amber-500/20 active:scale-95"
            title="هل دادن سریع بلوک‌ها به بعد در صورت بیدار شدن دیروقت"
          >
            <Zap className="w-3 h-3 fill-amber-400 text-amber-400 group-hover:scale-110 transition-transform" />
            <span>دیر بیدار شدم!</span>
          </button>

          {/* Compassionate Catch-up Button */}
          <button
            type="button"
            onClick={onOpenEmergencyRecovery}
            className="group flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-black rounded-lg text-[11px] transition-all cursor-pointer shadow-xs shadow-rose-900/30 hover:shadow-rose-700/40 ring-1 ring-rose-400/40 active:scale-95"
            title="جاموندن از برنامه و تنظیم مجدد مهربانانه روز در صورت خستگی یا حواس‌پرتی"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-300 group-hover:rotate-12 transition-transform" />
            <span>جاموندن از برنامه اینطوری (جبران سریع)</span>
          </button>
        </div>
      </div>

      {/* 2. EXECUTIVE DOCK: BRANDING, CONTEXT, CALENDAR NAVIGATOR & LIVE DATABASE BADGE */}
      <div className="max-w-[1920px] mx-auto px-3 sm:px-5 py-2.5 border-b border-slate-800/80 flex flex-col lg:flex-row lg:items-center justify-between gap-3 bg-slate-900/60 backdrop-blur-md">
        {/* Brand & Dynamic Title Section */}
        <div className="flex items-center gap-3.5 min-w-0 max-w-xl">
          <div className="relative group">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-purple-700 text-white flex items-center justify-center shadow-lg shadow-indigo-600/25 shrink-0 ring-2 ring-indigo-400/40 group-hover:scale-105 transition-all">
              <Clock className="w-5 h-5 text-white stroke-[2.5]" />
            </div>
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-900 ring-1 ring-emerald-400 animate-pulse" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={plannerTitle}
                onChange={(e) => onUpdateTitle(e.target.value)}
                aria-label="عنوان برنامه‌ریز"
                className="font-black text-white text-base sm:text-lg bg-transparent hover:bg-slate-800/60 focus:bg-slate-800/90 px-2 py-0.5 rounded-lg border border-transparent focus:border-indigo-500 focus:outline-hidden transition-all w-full truncate placeholder-slate-500 shadow-2xs"
                title="برای ویرایش عنوان کلیک کنید"
              />
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-extrabold shrink-0 shadow-2xs flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>سیستم ضدشکننده</span>
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <Calendar className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <input
                type="text"
                value={weekRange}
                onChange={(e) => onUpdateWeekRange(e.target.value)}
                placeholder="توضیح هفته یا اسپرینت جاری..."
                aria-label="بازه زمانی هفته"
                className="text-xs text-slate-300 bg-transparent hover:bg-slate-800/60 focus:bg-slate-800/90 px-2 py-0.5 rounded-md border border-transparent focus:border-indigo-500/70 focus:outline-hidden w-full truncate font-medium transition-all"
              />
            </div>
          </div>
        </div>

        {/* Center: Interactive Shamsi Calendar Navigator Dock */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 shadow-inner shrink-0 self-start lg:self-center ring-1 ring-slate-800/60">
          {onPrevWeek && (
            <button
              type="button"
              onClick={onPrevWeek}
              className="p-2 rounded-xl hover:bg-slate-800/80 text-slate-300 hover:text-white transition-all cursor-pointer active:scale-90"
              title="هفته قبل (کلید تیر راست)"
            >
              <ChevronRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          )}

          <button
            type="button"
            onClick={onOpenCalendar}
            className="group flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-black bg-slate-800/90 hover:bg-slate-700/80 text-slate-100 border border-slate-700/60 shadow-xs transition-all cursor-pointer hover:border-indigo-500/50"
            title="تقویم شمسی و انتخاب تاریخ دقیق"
          >
            <CalendarDays className="w-4 h-4 text-indigo-400 shrink-0 group-hover:scale-110 transition-transform" />
            <span className="text-slate-300 hidden sm:inline font-bold">تقویم شمسی:</span>
            <span className="font-mono text-indigo-300 bg-indigo-950/80 px-2.5 py-0.5 rounded-lg text-xs font-black border border-indigo-500/30 shrink-0 shadow-2xs">
              {toFaDigits(jDate.jd)} {jalaliMonthName} {toFaDigits(jDate.jy)}
            </span>
          </button>

          {onNextWeek && (
            <button
              type="button"
              onClick={onNextWeek}
              className="p-2 rounded-xl hover:bg-slate-800/80 text-slate-300 hover:text-white transition-all cursor-pointer active:scale-90"
              title="هفته بعد (کلید تیر چپ)"
            >
              <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
            </button>
          )}

          {onOpenCreateWeek && (
            <button
              type="button"
              onClick={onOpenCreateWeek}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs shadow-emerald-900/30 transition-all cursor-pointer mr-0.5 hover:scale-102 active:scale-95"
              title="ایجاد اسپرینت یا هفته جدید"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>هفته جدید</span>
            </button>
          )}
        </div>

        {/* Left: Durable Storage / Database Live Health Badge */}
        {onOpenDatabaseSettings && (
          <button
            type="button"
            onClick={onOpenDatabaseSettings}
            className="group flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-emerald-950/50 to-slate-900 hover:from-emerald-900/60 hover:to-slate-850 border border-emerald-500/30 shadow-xs transition-all cursor-pointer shrink-0 self-start lg:self-center hover:border-emerald-400/60 active:scale-98"
            title="وضعیت پایگاه داده: ذخیره پایدار و فعال. کلیک برای مدیریت دیتابیس"
          >
            <div className="relative flex items-center justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping absolute opacity-75" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 relative shrink-0 ring-2 ring-emerald-950" />
            </div>
            <div className="text-right">
              <div className="text-xs font-black text-emerald-300 flex items-center gap-1.5">
                <span>دیتابیس ابدی فعال</span>
                <Database className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-[10px] text-slate-400 font-mono font-semibold">
                {toFaDigits(savedWeeksCount)} هفته ذخیره پایدار
              </div>
            </div>
          </button>
        )}
      </div>

      {/* 3. EXECUTIVE POWER TOOLS DOCK & QUICK LAUNCHERS */}
      <div className="max-w-[1920px] mx-auto px-3 sm:px-5 py-2 flex flex-wrap items-center justify-between gap-2.5 text-xs bg-slate-950/40">
        {/* Core Actions: AI Assistant, Deep Focus, Daily Audit & Conflict Resolver */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* AI Planner Assistant Button */}
          {onOpenAiPlanner && (
            <button
              type="button"
              onClick={onOpenAiPlanner}
              className="group relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black text-white bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-500 hover:via-purple-500 hover:to-indigo-600 shadow-md shadow-indigo-900/40 transition-all cursor-pointer ring-2 ring-indigo-400/40 hover:ring-indigo-300 hover:scale-102 active:scale-95"
              title="دستیار هوشمند برنامه‌ریزی با هوش مصنوعی (Gemini AI)"
            >
              <Sparkles className="w-4 h-4 text-amber-300 group-hover:rotate-45 transition-transform" />
              <span>دستیار هوش مصنوعی</span>
              <span className="text-[9px] bg-white/20 text-white px-1.5 py-0.5 rounded-md font-mono font-bold tracking-wider">
                AI
              </span>
            </button>
          )}

          {/* Deep Focus Mode Button (With glowing neon pulse when active block exists) */}
          {onOpenFocusMode && (
            <button
              type="button"
              onClick={onOpenFocusMode}
              className={`group relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-black text-white transition-all cursor-pointer shadow-md active:scale-95 ${
                activeBlockTitle
                  ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 ring-2 ring-amber-300/80 shadow-orange-950/60 animate-pulse'
                  : 'bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600 border border-slate-600/70 text-slate-200'
              }`}
              title="ورود به حالت تمام‌صفحه فوکوس عمیق با تایمر زنده و راهنمای تسک فعلی"
            >
              <Flame
                className={`w-4 h-4 ${
                  activeBlockTitle
                    ? 'text-amber-200 fill-amber-300 animate-bounce'
                    : 'text-amber-400'
                }`}
              />
              <span>حالت فوکوس عمیق</span>
              {activeBlockTitle ? (
                <span className="max-w-[130px] truncate text-[10px] bg-black/40 px-2 py-0.5 rounded-md font-bold text-amber-200 border border-amber-400/30">
                  {activeBlockTitle}
                </span>
              ) : (
                <span className="text-[10px] text-slate-400 font-normal">آماده</span>
              )}
            </button>
          )}

          {/* Smart Conflict Resolver Button */}
          {onOpenConflictResolver && conflictsCount > 0 && (
            <button
              type="button"
              onClick={onOpenConflictResolver}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black text-rose-200 bg-rose-950/80 hover:bg-rose-900/90 border border-rose-500/60 shadow-md shadow-rose-950/50 transition-all cursor-pointer animate-pulse active:scale-95"
              title="شناسایی تداخل‌های هم‌پوشانی کارت‌ها - کلیک برای رفع خودکار"
            >
              <ShieldAlert className="w-4 h-4 text-rose-400 stroke-[2.5]" />
              <span>{toFaDigits(conflictsCount)} تداخل</span>
              <span className="text-[10px] bg-rose-600 text-white px-2 py-0.5 rounded-md font-bold">
                رفع هوشمند
              </span>
            </button>
          )}

          {/* Karnameh & Reports Dropdown Dock */}
          <div className="relative">
            <div className="flex items-center bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl shadow-md shadow-emerald-950/40 transition-all overflow-hidden ring-1 ring-emerald-400/40">
              <button
                type="button"
                onClick={onOpenDailyReport}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-black cursor-pointer active:bg-emerald-700"
                title="ثبت کارنامه پایان روز و بررسی دستاوردها"
              >
                <GraduationCap className="w-4 h-4 text-emerald-200" />
                <span>کارنامه روز</span>
              </button>
              <button
                type="button"
                onClick={() => setReportsMenuOpen(!reportsMenuOpen)}
                className="px-2 py-2 hover:bg-emerald-700 border-r border-emerald-500/50 cursor-pointer"
                title="سایر گزارش‌ها و آرشیو کارنامه‌ها"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Reports Dropdown Menu */}
            {reportsMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setReportsMenuOpen(false)}
                />
                <div className="absolute right-0 mt-1.5 w-64 bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-700/80 p-1.5 z-50 animate-in fade-in zoom-in-95 space-y-1 text-right">
                  <button
                    type="button"
                    onClick={() => {
                      setReportsMenuOpen(false);
                      onOpenDailyReport();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2.5 rounded-xl text-xs font-bold text-slate-100 hover:bg-emerald-950/60 hover:text-emerald-300 border border-transparent hover:border-emerald-500/30 transition-all cursor-pointer"
                  >
                    <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                      <GraduationCap className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-black text-slate-100">کارنامه و ثبت عملکرد روزانه</div>
                      <div className="text-[10px] text-slate-400 font-normal">
                        نمره‌دهی زنده، ممیزی گام‌به‌گام و صدور تصویر
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setReportsMenuOpen(false);
                      onOpenAuditHistory();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2.5 rounded-xl text-xs font-bold text-slate-100 hover:bg-emerald-950/60 hover:text-emerald-300 border border-transparent hover:border-emerald-500/30 transition-all cursor-pointer"
                  >
                    <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                      <Database className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-black text-slate-100">آرشیو کارنامه‌های ذخیره‌شده</div>
                      <div className="text-[10px] text-slate-400 font-normal">
                        تاریخچه گزارش‌های روزهای گذشته و تحلیل رشد
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setReportsMenuOpen(false);
                      onOpenSpecialReport();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2.5 rounded-xl text-xs font-bold text-slate-100 hover:bg-indigo-950/60 hover:text-indigo-300 border border-transparent hover:border-indigo-500/30 transition-all cursor-pointer"
                  >
                    <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
                      <BrainCircuit className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-black text-slate-100">گزارش ویژه و تحلیلی هفتگی</div>
                      <div className="text-[10px] text-slate-400 font-normal">
                        تحلیل سهم پایتون، پایتورچ و کار عمیق
                      </div>
                    </div>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Secondary Tools: Storage, Export, Settings, Reminders, Interval */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Database Manager Button */}
          {onOpenDatabaseSettings && (
            <button
              type="button"
              onClick={onOpenDatabaseSettings}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-200 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 shadow-xs transition-all cursor-pointer"
              title="مدیریت جامع پایگاه داده، بررسی هفته‌های ذخیره‌شده، حذف یا جایگزینی امن"
            >
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              <span>مدیریت دیتابیس</span>
            </button>
          )}

          {/* Export & Save Dropdown Menu */}
          <div className="relative">
            <div className="flex items-center bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl border border-slate-700/70 shadow-xs transition-all overflow-hidden">
              <button
                type="button"
                onClick={onPrint}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold cursor-pointer"
                title="چاپ هفتگی A4 / دانلود PDF"
              >
                <Printer className="w-3.5 h-3.5 text-slate-300" />
                <span>چاپ و PDF</span>
              </button>
              <button
                type="button"
                onClick={() => setExportMenuOpen(!exportMenuOpen)}
                className="px-1.5 py-1.5 hover:bg-slate-600 border-r border-slate-700 cursor-pointer"
                title="سایر گزینه‌های ذخیره و خروجی"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Export Dropdown Menu */}
            {exportMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setExportMenuOpen(false)}
                />
                <div className="absolute left-0 mt-1.5 w-60 bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-700/80 p-1.5 z-50 animate-in fade-in zoom-in-95 space-y-1 text-right">
                  <button
                    type="button"
                    onClick={() => {
                      setExportMenuOpen(false);
                      onSaveJSON();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2 rounded-xl text-xs font-bold text-slate-200 hover:bg-slate-800 hover:text-white cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-blue-400" />
                    <span>ذخیره فایل برنامه (JSON)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setExportMenuOpen(false);
                      fileInputRef.current?.click();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2 rounded-xl text-xs font-bold text-slate-200 hover:bg-slate-800 hover:text-white cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-emerald-400" />
                    <span>بارگذاری فایل از سیستم</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setExportMenuOpen(false);
                      onOpenOfflineExport();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2 rounded-xl text-xs font-bold text-slate-200 hover:bg-amber-950/50 hover:text-amber-300 cursor-pointer"
                  >
                    <Laptop className="w-4 h-4 text-amber-400" />
                    <span>نسخه مستقل آفلاین (HTML)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setExportMenuOpen(false);
                      onOpenJsonModal();
                    }}
                    className="w-full text-right flex items-center gap-2.5 p-2 rounded-xl text-xs font-bold text-slate-200 hover:bg-indigo-950/50 hover:text-indigo-300 cursor-pointer"
                  >
                    <Code2 className="w-4 h-4 text-indigo-400" />
                    <span>اتصال به هوش مصنوعی (AI JSON)</span>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Slot Interval Toggle (15m / 30m) */}
          <button
            type="button"
            onClick={onToggleSlotInterval}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-300 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 transition-all cursor-pointer"
            title="تغییر گام زمانی جدول بین ۱۵ و ۳۰ دقیقه"
          >
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
            <span>گام: {slotInterval === 15 ? '۱۵ دقیقه' : '۳۰ دقیقه'}</span>
          </button>

          {/* Categories Manager */}
          <button
            type="button"
            onClick={onOpenCategoryManager}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold text-purple-300 bg-purple-950/40 hover:bg-purple-900/60 border border-purple-600/40 shadow-xs transition-all cursor-pointer"
            title="مدیریت و ایجاد دسته‌بندی‌های روان‌شناختی"
          >
            <Palette className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">دسته‌بندی‌ها</span>
          </button>

          {/* Audio Chime Reminders */}
          <button
            type="button"
            onClick={onOpenReminderSettings}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-600/40 shadow-xs transition-all cursor-pointer"
            title="تنظیمات یادآور و هشدارهای صوتی سر وقت"
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">یادآور صوتی</span>
          </button>

          {/* Interactive Tutorial */}
          <button
            type="button"
            onClick={onOpenTutorial}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-300 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 transition-all cursor-pointer"
            title="آموزش گام‌به‌گام و راهنمای ساده کار با برنامه"
          >
            <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">آموزش و راهنما</span>
          </button>

          {/* View Utilities: Stats, Fullscreen, Reset Sample, Clear All */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-xl border border-slate-800 shrink-0">
            {/* Stats Dashboard Toggle */}
            <button
              type="button"
              onClick={onToggleStats}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                showStats
                  ? 'bg-indigo-600 text-white shadow-xs font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="داشبورد تعادل هفتگی و تحلیل بار شناختی"
            >
              <BarChart3 className="w-4 h-4" />
            </button>

            {/* Fullscreen Mode */}
            {onToggleFullscreen && (
              <button
                type="button"
                onClick={onToggleFullscreen}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  isFullscreen
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="حالت تمام‌صفحه مانیتور"
              >
                {isFullscreen ? (
                  <Minimize2 className="w-4 h-4 stroke-[2.5]" />
                ) : (
                  <Maximize2 className="w-4 h-4 stroke-[2.5]" />
                )}
              </button>
            )}

            {/* Reset Sample Blocks */}
            <button
              type="button"
              onClick={onResetSample}
              className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
              title="بارگذاری نمونه پیش‌فرض"
            >
              <Sparkles className="w-4 h-4 text-amber-400/80" />
            </button>

            {/* Clear Current Week */}
            <button
              type="button"
              onClick={onClearAll}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
              title="پاک‌سازی هفته جاری"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Hidden File Input for JSON import */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".json,application/json"
          className="hidden"
          id="json-file-input"
        />
      </div>
    </header>
  );
};

